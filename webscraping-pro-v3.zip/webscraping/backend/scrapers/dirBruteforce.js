const axios = require('axios');
const { getAxiosConfig, smartDelay } = require('../utils/proxyManager');

// Comprehensive path list (500+)
const PATHS = [
  // Admin panels
  '/admin', '/admin/', '/admin/login', '/administrator', '/administrator/',
  '/wp-admin', '/wp-admin/', '/wp-login.php', '/wp-config.php',
  '/phpmyadmin', '/phpmyadmin/', '/pma', '/mysqladmin', '/myadmin',
  '/cpanel', '/whm', '/webmin', '/plesk',
  '/panel', '/control', '/controlpanel', '/manage', '/management',
  '/backend', '/backoffice', '/staff', '/moderator',
  '/dashboard', '/dashboard/', '/console', '/console/',
  // Sensitive files
  '/.env', '/.env.local', '/.env.development', '/.env.production', '/.env.example',
  '/.env.backup', '/.env.bak', '/.env.old', '/.env.save', '/.env.staging',
  '/.git', '/.git/config', '/.git/HEAD', '/.git/index', '/.gitignore',
  '/.svn', '/.svn/entries', '/.hg', '/.DS_Store',
  '/config.php', '/config.js', '/config.json', '/config.xml', '/config.yaml', '/config.yml',
  '/configuration.php', '/settings.php', '/settings.py', '/settings.json',
  '/database.php', '/db.php', '/database.yml', '/database.json',
  '/web.config', '/app.config', '/appsettings.json',
  '/composer.json', '/composer.lock', '/package.json', '/package-lock.json',
  '/yarn.lock', '/Gemfile', '/Gemfile.lock', '/requirements.txt', '/Pipfile',
  '/Dockerfile', '/docker-compose.yml', '/docker-compose.yaml',
  '/Makefile', '/Vagrantfile', '/.travis.yml', '/.circleci/config.yml',
  // Backup files
  '/backup', '/backup/', '/backups', '/backups/', '/bak', '/old',
  '/backup.sql', '/backup.zip', '/backup.tar.gz', '/site.zip', '/www.zip',
  '/database.sql', '/db.sql', '/dump.sql', '/mysql.sql', '/backup.db',
  // API
  '/api', '/api/', '/api/v1', '/api/v1/', '/api/v2', '/api/v2/', '/api/v3',
  '/api/users', '/api/user', '/api/admin', '/api/login', '/api/auth',
  '/api/token', '/api/key', '/api/config', '/api/status', '/api/health',
  '/graphql', '/graphql/', '/graphiql', '/playground',
  '/swagger', '/swagger/', '/swagger.json', '/swagger.yaml', '/swagger-ui',
  '/swagger-ui.html', '/api-docs', '/api-docs/', '/openapi.json', '/openapi.yaml',
  '/redoc', '/v1', '/v2', '/v3',
  // Documentation
  '/docs', '/docs/', '/documentation', '/doc', '/help', '/wiki',
  '/readme', '/README', '/README.md', '/CHANGELOG', '/CHANGELOG.md',
  '/LICENSE', '/license.txt', '/CONTRIBUTING.md',
  // Logs & Debug
  '/log', '/logs', '/logs/', '/error.log', '/access.log', '/debug.log',
  '/app.log', '/server.log', '/php_error.log', '/nginx.log',
  '/debug', '/debug/', '/test', '/test/', '/demo', '/demo/',
  '/phpinfo.php', '/info.php', '/test.php', '/php.php',
  '/_profiler', '/_debug_toolbar', '/laravel.log',
  '/storage/logs/laravel.log', '/var/log/nginx/error.log',
  // Source code
  '/source', '/src', '/app', '/application', '/code',
  '/.well-known', '/.well-known/security.txt', '/.well-known/change-password',
  '/security.txt', '/humans.txt', '/sitemap.xml', '/sitemap.xml.gz',
  '/robots.txt', '/crossdomain.xml', '/clientaccesspolicy.xml',
  // CMS specific
  '/wp-content/debug.log', '/wp-content/uploads/', '/wp-json/', '/wp-json/wp/v2/users',
  '/wp-json/wp/v2/posts', '/wp-json/wp/v2/pages',
  '/joomla.xml', '/configuration.php',
  '/sites/default/settings.php', '/sites/default/files/',
  // Cloud / Deploy
  '/.aws/credentials', '/.ssh/id_rsa', '/.ssh/known_hosts',
  '/server-status', '/server-info', '/nginx_status', '/fpm-status',
  '/health', '/health/', '/healthcheck', '/ping', '/status',
  '/metrics', '/metrics/', '/actuator', '/actuator/health', '/actuator/env',
  '/actuator/mappings', '/_health', '/_status', '/_metrics',
  // Misc
  '/upload', '/uploads', '/uploads/', '/files', '/files/', '/media', '/media/',
  '/temp', '/tmp', '/cache', '/assets', '/static',
  '/shell', '/cmd', '/exec', '/eval', '/shell.php', '/cmd.php',
  '/xmlrpc.php', '/.htaccess', '/.htpasswd',
  '/cgi-bin/', '/cgi-bin/test.cgi', '/cgi-bin/printenv',
  '/solr', '/solr/admin', '/jenkins', '/jenkins/script',
  '/jmx-console', '/web-console', '/invoker/JMXInvokerServlet',
];

async function bruteforce(url, options = {}) {
  const baseUrl = new URL(url.startsWith('http') ? url : `https://${url}`).origin;
  const found = [];
  const errors = [];
  const scanned = [];

  // Batched requests
  const batchSize = 10;
  const paths = options.quick ? PATHS.slice(0, 100) : PATHS;

  for (let i = 0; i < paths.length; i += batchSize) {
    const batch = paths.slice(i, i + batchSize);
    const batchResults = await Promise.all(batch.map(async (path) => {
      try {
        const config = await getAxiosConfig({ ...options, timeout: 6000 });
        const r = await axios.get(baseUrl + path, config);
        const status = r.status;
        const contentType = r.headers['content-type'] || '';
        const size = r.data ? String(r.data).length : 0;
        const title = typeof r.data === 'string' ? (r.data.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1]?.trim() || null) : null;

        if (status !== 404 && status !== 400) {
          const result = {
            path, status, contentType: contentType.split(';')[0].trim(),
            size, title: title?.slice(0, 60) || null,
            interesting: [200, 201, 301, 302, 401, 403, 500].includes(status),
            critical: status === 200 && (
              path.includes('.env') || path.includes('config') ||
              path.includes('.git') || path.includes('sql') ||
              path.includes('backup') || path.includes('admin') ||
              path.includes('phpinfo') || path.includes('credentials') ||
              path.includes('swagger') || path.includes('api-docs')
            ),
          };
          scanned.push(result);
          if (result.interesting) return result;
        }
        return null;
      } catch (_) { return null; }
    }));

    batchResults.forEach(r => { if (r) found.push(r); });

    // Smart delay between batches
    if (options.useDelay !== false) await smartDelay(100, 300);
  }

  // Sort: critical first, then by status code
  found.sort((a, b) => {
    if (a.critical && !b.critical) return -1;
    if (!a.critical && b.critical) return 1;
    return a.status - b.status;
  });

  return {
    baseUrl,
    totalScanned: paths.length,
    found,
    criticalFound: found.filter(f => f.critical).length,
    byStatus: {
      '200': found.filter(f => f.status === 200).length,
      '301/302': found.filter(f => [301, 302].includes(f.status)).length,
      '401/403': found.filter(f => [401, 403].includes(f.status)).length,
      '500': found.filter(f => f.status === 500).length,
    },
  };
}

module.exports = { bruteforce };
