const axios = require('axios');
const cheerio = require('cheerio');
const { getAxiosConfig, smartDelay } = require('../utils/proxyManager');

const PATTERNS = {
  'Google API Key':        { re: /AIza[0-9A-Za-z\-_]{35}/g,              severity: 'critical' },
  'Firebase Config':       { re: /firebase[^{]{0,50}\{[\s\S]{20,600}apiKey[\s\S]{0,200}\}/gi, severity: 'critical' },
  'Firebase DB URL':       { re: /https:\/\/[a-z0-9\-]+\.firebaseio\.com/g, severity: 'high' },
  'AWS Access Key':        { re: /AKIA[0-9A-Z]{16}/g,                     severity: 'critical' },
  'Stripe Public Key':     { re: /pk_(test|live)_[A-Za-z0-9]{24,}/g,      severity: 'medium' },
  'Stripe Secret Key':     { re: /sk_(test|live)_[A-Za-z0-9]{24,}/g,      severity: 'critical' },
  'JWT Token':             { re: /eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g, severity: 'high' },
  'Bearer Token':          { re: /Bearer\s+([A-Za-z0-9\-._~+/]{20,})/g,   severity: 'high' },
  'GitHub Token':          { re: /gh[ps]_[A-Za-z0-9]{36}/g,               severity: 'critical' },
  'Twilio SID':            { re: /AC[a-z0-9]{32}/g,                       severity: 'high' },
  'SendGrid Key':          { re: /SG\.[A-Za-z0-9\-_]{22}\.[A-Za-z0-9\-_]{43}/g, severity: 'critical' },
  'Slack Token':           { re: /xox[baprs]-[0-9]{10,13}-[0-9]{10,13}-[A-Za-z0-9]{24}/g, severity: 'critical' },
  'MongoDB URI':           { re: /mongodb(\+srv)?:\/\/[^\s"'<>]+/g,       severity: 'critical' },
  'MySQL URI':             { re: /mysql:\/\/[^\s"'<>]+/g,                  severity: 'critical' },
  'PostgreSQL URI':        { re: /postgres(?:ql)?:\/\/[^\s"'<>]+/g,       severity: 'critical' },
  'Redis URI':             { re: /redis(?:s)?:\/\/[^\s"'<>]+/g,           severity: 'high' },
  'Hardcoded Password':    { re: /(?:password|passwd|pwd)\s*[=:]\s*["']([^"']{6,50})["']/gi, severity: 'critical' },
  'Private Key':           { re: /-----BEGIN (?:RSA |EC )?PRIVATE KEY-----/g, severity: 'critical' },
  'ENV Variables':         { re: /process\.env\.[A-Z_][A-Z0-9_]{2,}/g,    severity: 'info' },
  'Source Map':            { re: /\/\/# sourceMappingURL=([^\s]+)/g,       severity: 'medium' },
  'Internal URL':          { re: /["'`](https?:\/\/localhost[^\s"'`<>]*)["'`]/g, severity: 'medium' },
  'GraphQL Endpoint':      { re: /["'`](https?:\/\/[^"'`\s]+\/graphql[^"'`\s]*)["'`]/g, severity: 'info' },
};

const STREAMING_PATTERNS = [
  { re: /["'`](https?:\/\/[^"'`\s]+\.m3u8[^"'`\s]*)["'`]/g,        type: 'HLS m3u8' },
  { re: /["'`](https?:\/\/[^"'`\s]+\.mpd[^"'`\s]*)["'`]/g,         type: 'MPEG-DASH' },
  { re: /(rtmps?:\/\/[^\s"'<>]+)/g,                                  type: 'RTMP' },
  { re: /["'`](https?:\/\/[^"'`\s]+\/live[^"'`\s]{0,60})["'`]/g,   type: 'Live Stream' },
  { re: /["'`](https?:\/\/[^"'`\s]+\/stream[^"'`\s]{0,60})["'`]/g, type: 'Stream URL' },
  { re: /["'`](https?:\/\/[^"'`\s]+\/manifest[^"'`\s]*)["'`]/g,    type: 'Manifest' },
  { re: /file\s*:\s*["'`](https?:\/\/[^"'`\s]+)["'`]/gi,            type: 'Player Source' },
  { re: /src\s*:\s*["'`](https?:\/\/[^"'`\s]+\.(?:mp4|webm|m3u8)[^"'`\s]*)["'`]/gi, type: 'Video Src' },
];

async function analyze(url, options = {}) {
  const config = await getAxiosConfig({ ...options, timeout: 20000 });
  const res = await axios.get(url, config);
  const $ = cheerio.load(res.data);

  const jsUrls = [];
  $('script[src]').each((_, el) => {
    try { jsUrls.push(new URL($(el).attr('src'), url).href); } catch (_) {}
  });

  const inlineScripts = [];
  $('script:not([src])').each((_, el) => {
    const c = $(el).html()?.trim();
    if (c && c.length > 30) inlineScripts.push(c);
  });

  const allFindings = [];
  const streamingApis = [];
  const fileResults = [];

  function analyzeContent(content, source) {
    const findings = [];
    for (const [label, { re, severity }] of Object.entries(PATTERNS)) {
      const safeRe = new RegExp(re.source, re.flags);
      const matches = [...content.matchAll(safeRe)];
      if (matches.length > 0) {
        const unique = [...new Set(matches.map(m => (m[1] || m[0]).trim()))].slice(0, 15);
        findings.push({ label, severity, matches: unique, count: matches.length, source });
      }
    }
    for (const { re, type } of STREAMING_PATTERNS) {
      const safeRe = new RegExp(re.source, re.flags);
      const matches = [...content.matchAll(safeRe)];
      matches.forEach(m => {
        const u = (m[1] || m[0]).trim();
        if (u.startsWith('http') || u.startsWith('rtmp')) {
          streamingApis.push({ type, url: u, source });
        }
      });
    }
    return findings;
  }

  inlineScripts.forEach((script, i) => {
    const findings = analyzeContent(script, `Inline Script #${i + 1}`);
    if (findings.length > 0) {
      allFindings.push(...findings);
      fileResults.push({ url: `Inline Script #${i + 1}`, size: script.length, findings, isInline: true });
    }
  });

  for (const jsUrl of jsUrls.slice(0, 20)) {
    try {
      if (options.useDelay) await smartDelay(300, 800);
      const jsConfig = await getAxiosConfig({ ...options, timeout: 10000 });
      const jsRes = await axios.get(jsUrl, jsConfig);
      const content = typeof jsRes.data === 'string' ? jsRes.data : JSON.stringify(jsRes.data);
      const findings = analyzeContent(content, jsUrl);
      fileResults.push({
        url: jsUrl,
        size: content.length,
        sizeKB: (content.length / 1024).toFixed(1) + ' KB',
        findings,
        hasSourceMap: content.includes('sourceMappingURL'),
        isMinified: content.split('\n').length < 5 && content.length > 500,
      });
      allFindings.push(...findings);
    } catch (e) {
      fileResults.push({ url: jsUrl, error: e.message, findings: [] });
    }
  }

  const summary = {};
  for (const f of allFindings) {
    if (!summary[f.label]) summary[f.label] = { count: 0, matches: [], severity: f.severity };
    summary[f.label].count += f.count;
    summary[f.label].matches.push(...f.matches);
  }
  for (const k in summary) {
    summary[k].matches = [...new Set(summary[k].matches)].slice(0, 20);
  }

  const seenStreams = new Set();
  const uniqueStreams = streamingApis.filter(s => {
    if (seenStreams.has(s.url)) return false;
    seenStreams.add(s.url);
    return true;
  });

  return {
    totalFiles: jsUrls.length,
    analyzedFiles: fileResults.filter(f => !f.error).length,
    inlineScripts: inlineScripts.length,
    totalFindings: allFindings.length,
    criticalFindings: allFindings.filter(f => f.severity === 'critical').length,
    jsUrls,
    fileResults,
    summary,
    streamingApis: uniqueStreams,
  };
}

module.exports = { analyze };
