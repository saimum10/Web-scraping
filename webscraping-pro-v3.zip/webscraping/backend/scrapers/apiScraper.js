const axios = require('axios');
const cheerio = require('cheerio');
const { getAxiosConfig, smartDelay } = require('../utils/proxyManager');

const ENDPOINT_PATTERNS = [
  /['"`]((?:\/api\/|\/v[0-9]+\/)[a-zA-Z0-9_\-/.%?&=#@:{}]+)['"`]/g,
  /(?:url|endpoint|path|src|href|action)\s*[=:]\s*['"`]((?:\/|https?:\/\/)[^'"` \n<>]{4,150})['"`]/gi,
  /fetch\s*\(\s*['"`]((?:\/|https?:\/\/)[^'"` \n<>]+)['"`]/gi,
  /axios\.[a-z]+\s*\(\s*['"`]((?:\/|https?:\/\/)[^'"` \n<>]+)['"`]/gi,
  /\$\.(?:ajax|get|post)\s*\(\s*['"`]((?:\/|https?:\/\/)[^'"` \n<>]+)['"`]/gi,
  /XMLHttpRequest[\s\S]{0,100}\.open\s*\([^,]+,\s*['"`]([^'"` ]+)['"`]/gi,
  /(?:GET|POST|PUT|DELETE|PATCH)\s*['",]\s*['"]?((?:\/|https?:\/\/)[^'"` \n<>]+)['"]?/gi,
];

const GRAPHQL_PATTERNS = [
  /gql`([\s\S]*?)`/g,
  /graphql`([\s\S]*?)`/g,
  /query\s+\w+[\s\S]{0,20}\{[\s\S]{10,400}\}/g,
  /mutation\s+\w+[\s\S]{0,20}[({][\s\S]{10,300}[})]/g,
  /subscription\s+\w+[\s\S]{0,20}\{[\s\S]{10,300}\}/g,
];

const WS_PATTERNS = [
  /new\s+WebSocket\s*\(\s*['"`](wss?:\/\/[^'"` <>\n]+)['"`]/gi,
  /socket(?:\.io)?\s*\(\s*['"`](https?:\/\/[^'"` <>\n]+)['"`]/gi,
  /EventSource\s*\(\s*['"`]((?:\/|https?:\/\/)[^'"` <>\n]+)['"`]/gi,
];

// Streaming API patterns
const STREAMING_PATTERNS = [
  { re: /['"`](https?:\/\/[^'"` <>\n]+\.m3u8[^'"` <>\n]*)['"`]/gi, type: 'HLS m3u8' },
  { re: /['"`](https?:\/\/[^'"` <>\n]+\.mpd[^'"` <>\n]*)['"`]/gi, type: 'MPEG-DASH' },
  { re: /(rtmps?:\/\/[^\s'"<>\n]+)/gi, type: 'RTMP' },
  { re: /['"`](https?:\/\/[^'"` <>\n]*\/live[^'"` <>\n]{0,50})['"`]/gi, type: 'Live Stream' },
  { re: /['"`](https?:\/\/[^'"` <>\n]*\/playlist[^'"` <>\n]*)['"`]/gi, type: 'Playlist' },
  { re: /['"`](https?:\/\/[^'"` <>\n]*\/manifest[^'"` <>\n]*)['"`]/gi, type: 'Manifest' },
  { re: /src\s*:\s*['"`](https?:\/\/[^'"` <>\n]+\.(?:mp4|webm|ogg|flv|avi)[^'"` <>\n]*)['"`]/gi, type: 'Video File' },
  { re: /file\s*:\s*['"`](https?:\/\/[^'"` <>\n]+)['"`]/gi, type: 'Player Source' },
];

function isValidEndpoint(ep) {
  if (!ep || ep.length < 2 || ep.length > 200) return false;
  const skip = ['.css', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.woff', '.ttf', '.ico', '.webp', '.map'];
  const lower = ep.toLowerCase();
  return !skip.some(ext => lower.endsWith(ext));
}

const PROBE_PATHS = [
  '/api', '/api/', '/api/v1', '/api/v2', '/graphql', '/swagger',
  '/swagger-ui.html', '/api-docs', '/openapi.json', '/openapi.yaml',
  '/health', '/status', '/metrics', '/ping', '/actuator/health',
  '/admin', '/.env', '/config', '/debug', '/v1', '/v2',
  '/wp-json/', '/wp-json/wp/v2/users', '/rest/api/2/issue',
];

async function discover(url, options = {}) {
  const baseUrl = new URL(url.startsWith('http') ? url : `https://${url}`).origin;
  const config = await getAxiosConfig({ ...options, timeout: 15000 });
  const res = await axios.get(url, config);
  const html = typeof res.data === 'string' ? res.data : '';
  const $ = cheerio.load(html);

  const jsUrls = [];
  $('script[src]').each((_, el) => {
    try { jsUrls.push(new URL($(el).attr('src'), url).href); } catch (_) {}
  });

  const allEndpoints = new Set();
  const graphqlQueries = [];
  const websockets = [];
  const formActions = [];
  const xhrPatterns = [];
  const streamingApis = [];

  function extractFromContent(content) {
    // Endpoints
    ENDPOINT_PATTERNS.forEach(pattern => {
      const flags = pattern.flags.includes('g') ? pattern.flags : pattern.flags + 'g';
      [...content.matchAll(new RegExp(pattern.source, flags))].forEach(m => {
        const ep = (m[1] || m[0]).trim();
        if (isValidEndpoint(ep)) allEndpoints.add(ep);
      });
    });

    // GraphQL
    GRAPHQL_PATTERNS.forEach(pattern => {
      const flags = pattern.flags.includes('g') ? pattern.flags : pattern.flags + 'g';
      [...content.matchAll(new RegExp(pattern.source, flags))].forEach(m => {
        if (m[0]?.length > 15 && m[0]?.length < 1000) graphqlQueries.push(m[0].trim().slice(0, 500));
      });
    });

    // WebSocket
    WS_PATTERNS.forEach(pattern => {
      const flags = pattern.flags.includes('g') ? pattern.flags : pattern.flags + 'g';
      [...content.matchAll(new RegExp(pattern.source, flags))].forEach(m => {
        const ws = m[1] || m[0];
        if (ws) websockets.push(ws.trim());
      });
    });

    // Streaming APIs
    STREAMING_PATTERNS.forEach(({ re, type }) => {
      const flags = re.flags.includes('g') ? re.flags : re.flags + 'g';
      [...content.matchAll(new RegExp(re.source, flags))].forEach(m => {
        const streamUrl = (m[1] || m[0]).trim();
        if (streamUrl.startsWith('http') || streamUrl.startsWith('rtmp')) {
          streamingApis.push({ type, url: streamUrl });
        }
      });
    });

    // XHR with method
    const xhrRe = /(GET|POST|PUT|DELETE|PATCH)\s*[,'"]\s*['"]?((?:\/|https?:\/\/)[^'"` \n<>]{3,150})['"]?/gi;
    [...content.matchAll(xhrRe)].forEach(m => {
      const ep = m[2]?.trim();
      if (ep && isValidEndpoint(ep)) {
        xhrPatterns.push({ method: m[1].toUpperCase(), endpoint: ep });
        allEndpoints.add(ep);
      }
    });
  }

  // Analyze inline scripts
  $('script:not([src])').each((_, el) => {
    const c = $(el).html() || '';
    if (c.trim().length > 20) extractFromContent(c);
  });

  // Analyze HTML attributes (data-src, href, action, etc.)
  extractFromContent(html);

  // Form actions
  $('form').each((_, form) => {
    const action = $(form).attr('action');
    const method = ($(form).attr('method') || 'GET').toUpperCase();
    if (action) {
      try {
        formActions.push({ action: new URL(action, url).href, method });
        allEndpoints.add(action);
      } catch (_) {}
    }
  });

  // Analyze JS files
  for (const jsUrl of jsUrls.slice(0, 15)) {
    try {
      if (options.useDelay !== false) await smartDelay(200, 500);
      const jsConfig = await getAxiosConfig({ ...options, timeout: 8000 });
      const jsRes = await axios.get(jsUrl, jsConfig);
      const content = typeof jsRes.data === 'string' ? jsRes.data : JSON.stringify(jsRes.data);
      extractFromContent(content);
    } catch (_) {}
  }

  // Probe common paths
  const probeResults = [];
  for (const path of PROBE_PATHS) {
    try {
      const probeConfig = await getAxiosConfig({ timeout: 5000 });
      const r = await axios.get(baseUrl + path, probeConfig);
      if (r.status !== 404 && r.status !== 400) {
        const isJson = typeof r.data === 'object';
        probeResults.push({
          path, status: r.status,
          contentType: r.headers['content-type']?.split(';')[0] || '',
          size: JSON.stringify(r.data || '').length,
          interesting: r.status === 200 || r.status === 401 || r.status === 403,
          isJson,
          preview: isJson ? JSON.stringify(r.data).slice(0, 100) : null,
        });
      }
    } catch (_) {}
    if (options.useDelay !== false) await smartDelay(100, 200);
  }

  // Deduplicate
  const uniqueEndpoints = [...allEndpoints].filter(Boolean);
  const uniqueXhr = [...new Map(xhrPatterns.map(x => [x.endpoint, x])).values()];
  const uniqueStreams = [...new Map(streamingApis.map(s => [s.url, s])).values()];
  const uniqueGQL = [...new Set(graphqlQueries)].slice(0, 15);
  const uniqueWS = [...new Set(websockets)];

  // Categorize endpoints
  const categorized = {
    api: uniqueEndpoints.filter(e => /\/api\//i.test(e)),
    auth: uniqueEndpoints.filter(e => /\/(auth|login|logout|register|signup|token|oauth)\//i.test(e)),
    admin: uniqueEndpoints.filter(e => /\/(admin|dashboard|panel|manage|backend)\//i.test(e)),
    data: uniqueEndpoints.filter(e => /\/(data|fetch|load|get|list|search|query)\//i.test(e)),
    upload: uniqueEndpoints.filter(e => /\/(upload|file|media|image|attachment)\//i.test(e)),
    other: uniqueEndpoints.filter(e =>
      !/\/api\//i.test(e) && !/\/(auth|login|logout|register|token|oauth)\//i.test(e) &&
      !/\/(admin|dashboard|panel)\//i.test(e) && !/\/(data|fetch|load|get|list|search)\//i.test(e) &&
      !/\/(upload|file|media|image)\//i.test(e)
    ),
  };

  return {
    totalEndpoints: uniqueEndpoints.length,
    jsFilesAnalyzed: Math.min(jsUrls.length, 15),
    endpoints: uniqueEndpoints.slice(0, 200),
    categorized: Object.fromEntries(Object.entries(categorized).map(([k, v]) => [k, v.slice(0, 50)])),
    xhrPatterns: uniqueXhr.slice(0, 60),
    graphqlQueries: uniqueGQL,
    websockets: uniqueWS,
    formActions,
    streamingApis: uniqueStreams,
    probeResults,
  };
}

module.exports = { discover };
