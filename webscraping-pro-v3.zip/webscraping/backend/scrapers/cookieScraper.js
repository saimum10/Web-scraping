const axios = require('axios');
const cheerio = require('cheerio');
const { getAxiosConfig } = require('../utils/proxyManager');

function parseCookie(str) {
  const parts = str.split(';').map(p => p.trim());
  const eqIdx = parts[0].indexOf('=');
  const name = parts[0].slice(0, eqIdx).trim();
  const value = parts[0].slice(eqIdx + 1).trim();
  const cookie = { name, value: value.slice(0, 300), raw: str };

  parts.slice(1).forEach(attr => {
    const lower = attr.toLowerCase();
    if (lower === 'httponly') cookie.httpOnly = true;
    else if (lower === 'secure') cookie.secure = true;
    else if (lower.startsWith('samesite=')) cookie.sameSite = attr.split('=')[1]?.trim();
    else if (lower.startsWith('path=')) cookie.path = attr.split('=')[1]?.trim();
    else if (lower.startsWith('domain=')) cookie.domain = attr.split('=')[1]?.trim();
    else if (lower.startsWith('expires=')) cookie.expires = attr.slice(8).trim();
    else if (lower.startsWith('max-age=')) cookie.maxAge = attr.split('=')[1]?.trim();
  });

  const n = name.toLowerCase();
  if (n.includes('sess') || n === 'sid' || n.includes('session')) cookie.type = 'Session Token';
  else if (n.includes('auth') || n.includes('token') || n.includes('jwt')) cookie.type = 'Auth Token';
  else if (n.includes('csrf') || n.includes('xsrf')) cookie.type = 'CSRF Token';
  else if (n.includes('_ga') || n.includes('_fb') || n.includes('_gid') || n.includes('track')) cookie.type = 'Tracking';
  else if (n.includes('pref') || n.includes('lang') || n.includes('theme') || n.includes('dark')) cookie.type = 'Preference';
  else if (n.includes('cart') || n.includes('basket') || n.includes('shop')) cookie.type = 'Commerce';
  else cookie.type = 'General';

  const issues = [];
  if (!cookie.httpOnly) issues.push('HttpOnly নেই');
  if (!cookie.secure) issues.push('Secure নেই');
  if (!cookie.sameSite) issues.push('SameSite নেই');
  cookie.securityIssues = issues;
  cookie.securityRating = issues.length === 0 ? 'safe' : issues.length === 1 ? 'warning' : 'danger';

  if (value.startsWith('eyJ') && value.split('.').length === 3) {
    cookie.isJwt = true;
    try {
      const payload = JSON.parse(Buffer.from(value.split('.')[1], 'base64').toString());
      cookie.jwtPayload = payload;
    } catch (_) {}
  }

  if (!cookie.isJwt && /^[A-Za-z0-9+/]{20,}={0,2}$/.test(value)) {
    try {
      const decoded = Buffer.from(value, 'base64').toString('utf-8');
      if (/[\w{}"':]+/.test(decoded)) cookie.decodedValue = decoded.slice(0, 200);
    } catch (_) {}
  }

  return cookie;
}

async function extract(url, options = {}) {
  const config = await getAxiosConfig({ ...options, timeout: 15000 });
  const res = await axios.get(url, { ...config, validateStatus: () => true });
  const html = typeof res.data === 'string' ? res.data : '';
  const $ = cheerio.load(html);

  const cookies = [];
  const rawCookies = res.headers['set-cookie'];
  if (rawCookies) {
    (Array.isArray(rawCookies) ? rawCookies : [rawCookies]).forEach(cs => {
      try { cookies.push(parseCookie(cs)); } catch (_) {}
    });
  }

  const localStorageHints = [];
  $('script:not([src])').each((_, el) => {
    const c = $(el).html() || '';
    [...c.matchAll(/localStorage\.(setItem|getItem|removeItem)\s*\(\s*['"]([^'"]+)['"]/g)].forEach(m => localStorageHints.push({ storage: 'localStorage', action: m[1], key: m[2] }));
    [...c.matchAll(/sessionStorage\.(setItem|getItem|removeItem)\s*\(\s*['"]([^'"]+)['"]/g)].forEach(m => localStorageHints.push({ storage: 'sessionStorage', action: m[1], key: m[2] }));
  });

  const authPatterns = [];
  $('script:not([src])').each((_, el) => {
    const c = $(el).html() || '';
    [...c.matchAll(/['"]?(Authorization|X-Auth-Token|X-API-Key|X-CSRF-Token|Bearer)['"]?/gi)].forEach(m => authPatterns.push(m[1]));
  });

  return {
    totalCookies: cookies.length,
    cookies,
    summary: {
      session: cookies.filter(c => c.type === 'Session Token').length,
      auth: cookies.filter(c => c.type === 'Auth Token').length,
      csrf: cookies.filter(c => c.type === 'CSRF Token').length,
      tracking: cookies.filter(c => c.type === 'Tracking').length,
      dangerous: cookies.filter(c => c.securityRating === 'danger').length,
    },
    localStorageHints: [...new Map(localStorageHints.map(h => [h.key, h])).values()].slice(0, 30),
    authHeaderPatterns: [...new Set(authPatterns)],
    corsHeaders: {
      origin: res.headers['access-control-allow-origin'] || null,
      credentials: res.headers['access-control-allow-credentials'] || null,
      headers: res.headers['access-control-allow-headers'] || null,
      methods: res.headers['access-control-allow-methods'] || null,
    },
    hasIndexedDB: html.includes('indexedDB') || html.includes('IDBDatabase'),
  };
}

module.exports = { extract };
