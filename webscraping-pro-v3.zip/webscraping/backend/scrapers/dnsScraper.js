const dns = require('dns').promises;
const axios = require('axios');

function extractHostname(url) {
  try { return new URL(url.startsWith('http') ? url : `https://${url}`).hostname; }
  catch (_) { return url.replace(/^https?:\/\//, '').split('/')[0]; }
}
async function safe(fn) { try { return await fn(); } catch (_) { return null; } }

async function lookup(url) {
  const hostname = extractHostname(url);
  const [a, aaaa, mx, ns, txt, cname] = await Promise.all([
    safe(() => dns.resolve4(hostname)),
    safe(() => dns.resolve6(hostname)),
    safe(() => dns.resolveMx(hostname)),
    safe(() => dns.resolveNs(hostname)),
    safe(() => dns.resolveTxt(hostname)),
    safe(() => dns.resolveCname(hostname)),
  ]);
  let reverseDns = null;
  if (a?.[0]) reverseDns = await safe(() => dns.reverse(a[0]));
  let whois = null;
  try {
    const d = (await axios.get(`https://rdap.org/domain/${hostname}`, { timeout: 10000 })).data;
    whois = {
      name: d.ldhName || hostname,
      registrar: d.entities?.find(e => e.roles?.includes('registrar'))?.vcardArray?.[1]?.find(v => v[0] === 'fn')?.[3] || '',
      registered: d.events?.find(e => e.eventAction === 'registration')?.eventDate || '',
      expires: d.events?.find(e => e.eventAction === 'expiration')?.eventDate || '',
      updated: d.events?.find(e => e.eventAction === 'last changed')?.eventDate || '',
      status: d.status || [],
    };
  } catch (_) {}
  let cdn = 'Unknown';
  if (a?.[0]) {
    const ip = a[0];
    if (ip.startsWith('104.') || ip.startsWith('172.64.') || ip.startsWith('162.158.')) cdn = 'Cloudflare';
    else if (ip.startsWith('13.') || ip.startsWith('52.') || ip.startsWith('54.')) cdn = 'AWS';
    else if (ip.startsWith('151.101.')) cdn = 'Fastly';
  }
  if (cdn === 'Unknown' && ns) {
    if (ns.some(n => n.includes('cloudflare'))) cdn = 'Cloudflare';
    else if (ns.some(n => n.includes('awsdns'))) cdn = 'AWS Route53';
    else if (ns.some(n => n.includes('google'))) cdn = 'Google Cloud';
    else if (ns.some(n => n.includes('azure'))) cdn = 'Azure';
  }
  return { hostname, ipv4: a || [], ipv6: aaaa || [], mx: mx || [], nameservers: ns || [], txt: txt?.map(t => t.join('')) || [], cname: cname || [], reverseDns, whois, cdn };
}

module.exports = { lookup };
