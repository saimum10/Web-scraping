const axios = require('axios');
const cheerio = require('cheerio');
const { getAxiosConfig } = require('../utils/proxyManager');

// Technology signatures database
const TECH_DB = [
  // CMS
  { name: 'WordPress',      category: 'CMS',        confidence: 'High',   patterns: { html: [/wp-content\//i, /wp-includes\//i], meta: [/wordpress/i], headers: {} } },
  { name: 'Joomla',         category: 'CMS',        confidence: 'High',   patterns: { html: [/\/components\/com_/i, /joomla/i], meta: [/joomla/i], headers: {} } },
  { name: 'Drupal',         category: 'CMS',        confidence: 'High',   patterns: { html: [/drupal/i, /sites\/default\/files/i], meta: [/drupal/i], headers: { 'x-generator': /drupal/i } } },
  { name: 'Magento',        category: 'E-Commerce', confidence: 'High',   patterns: { html: [/mage\/cookies/i, /Mage\.Cookies/i], meta: [], headers: {} } },
  { name: 'Shopify',        category: 'E-Commerce', confidence: 'High',   patterns: { html: [/shopify/i, /myshopify\.com/i], meta: [], headers: { 'x-shopify-stage': /./i } } },
  { name: 'WooCommerce',    category: 'E-Commerce', confidence: 'High',   patterns: { html: [/woocommerce/i, /wc-ajax/i], meta: [], headers: {} } },
  { name: 'PrestaShop',     category: 'E-Commerce', confidence: 'High',   patterns: { html: [/prestashop/i], meta: [/prestashop/i], headers: {} } },
  // Frameworks
  { name: 'React',          category: 'JS Framework', confidence: 'High', patterns: { html: [/__reactFiber/i, /react-root/i, /_reactRootContainer/i, /data-reactroot/i], meta: [], scripts: [/react(?:\.min)?\.js/i, /react-dom/i], headers: {} } },
  { name: 'Vue.js',         category: 'JS Framework', confidence: 'High', patterns: { html: [/data-v-[a-f0-9]+/i, /v-cloak/i], meta: [], scripts: [/vue(?:\.min)?\.js/i, /vue@/i], headers: {} } },
  { name: 'Angular',        category: 'JS Framework', confidence: 'High', patterns: { html: [/ng-version/i, /ng-app/i, /_nghost/i, /_ngcontent/i], meta: [], scripts: [/angular(?:\.min)?\.js/i], headers: {} } },
  { name: 'Next.js',        category: 'JS Framework', confidence: 'High', patterns: { html: [/__NEXT_DATA__/i, /_next\/static/i], meta: [], headers: { 'x-powered-by': /next\.js/i } } },
  { name: 'Nuxt.js',        category: 'JS Framework', confidence: 'High', patterns: { html: [/__nuxt/i, /_nuxt\//i], meta: [], headers: { 'x-powered-by': /nuxt/i } } },
  { name: 'Svelte',         category: 'JS Framework', confidence: 'Medium',patterns: { html: [/svelte/i, /__svelte/i], meta: [], headers: {} } },
  { name: 'jQuery',         category: 'JS Library',  confidence: 'High',  patterns: { html: [], meta: [], scripts: [/jquery[.\-]([0-9.]+)(?:\.min)?\.js/i, /jquery(?:\.min)?\.js/i], headers: {} }, versionRe: /jquery[.\-]([0-9.]+)/i },
  { name: 'Bootstrap',      category: 'CSS Framework',confidence: 'High', patterns: { html: [/class="[^"]*(?:container|row|col-)/i], meta: [], scripts: [/bootstrap(?:\.min)?\.js/i], links: [/bootstrap(?:\.min)?\.css/i], headers: {} } },
  { name: 'Tailwind CSS',   category: 'CSS Framework',confidence: 'High', patterns: { html: [/class="[^"]*(?:flex|grid|text-[a-z]+-[0-9]+|bg-[a-z]+-[0-9]+)/i], meta: [], links: [/tailwind/i], headers: {} } },
  // Backend
  { name: 'Laravel',        category: 'Backend',     confidence: 'High',   patterns: { html: [/laravel/i], cookies: [/laravel_session/i, /XSRF-TOKEN/i], headers: { 'set-cookie': /laravel_session/i } } },
  { name: 'Django',         category: 'Backend',     confidence: 'High',   patterns: { html: [/csrfmiddlewaretoken/i], cookies: [/csrftoken/i, /sessionid/i], headers: { 'x-frame-options': /sameorigin/i } } },
  { name: 'Ruby on Rails',  category: 'Backend',     confidence: 'High',   patterns: { html: [/csrf-token/i], headers: { 'x-powered-by': /phusion passenger/i, 'server': /passenger/i } } },
  { name: 'ASP.NET',        category: 'Backend',     confidence: 'High',   patterns: { html: [/__VIEWSTATE/i, /__EVENTVALIDATION/i], headers: { 'x-powered-by': /asp\.net/i, 'x-aspnet-version': /./i } } },
  { name: 'Express.js',     category: 'Backend',     confidence: 'Medium', patterns: { html: [], headers: { 'x-powered-by': /express/i } } },
  { name: 'Flask',          category: 'Backend',     confidence: 'Medium', patterns: { html: [], cookies: [/session/i], headers: { 'server': /werkzeug/i } } },
  { name: 'Spring',         category: 'Backend',     confidence: 'Medium', patterns: { html: [], headers: { 'x-application-context': /./i } } },
  // Servers
  { name: 'Nginx',          category: 'Web Server',  confidence: 'High',   patterns: { html: [], headers: { 'server': /nginx/i } }, versionRe: /nginx\/([0-9.]+)/i, headerKey: 'server' },
  { name: 'Apache',         category: 'Web Server',  confidence: 'High',   patterns: { html: [], headers: { 'server': /apache/i } }, versionRe: /apache\/([0-9.]+)/i, headerKey: 'server' },
  { name: 'IIS',            category: 'Web Server',  confidence: 'High',   patterns: { html: [], headers: { 'server': /microsoft-iis/i } }, versionRe: /iis\/([0-9.]+)/i, headerKey: 'server' },
  { name: 'LiteSpeed',      category: 'Web Server',  confidence: 'High',   patterns: { html: [], headers: { 'server': /litespeed/i, 'x-litespeed-cache': /./i } } },
  // CDN / Security
  { name: 'Cloudflare',     category: 'CDN',         confidence: 'High',   patterns: { html: [], headers: { 'server': /cloudflare/i, 'cf-ray': /./i } } },
  { name: 'Fastly',         category: 'CDN',         confidence: 'High',   patterns: { html: [], headers: { 'x-served-by': /cache-/i, 'x-fastly-request-id': /./i } } },
  { name: 'Akamai',         category: 'CDN',         confidence: 'High',   patterns: { html: [], headers: { 'x-akamai-transformed': /./i, 'x-check-cacheable': /./i } } },
  // Analytics
  { name: 'Google Analytics', category: 'Analytics', confidence: 'High',  patterns: { html: [/google-analytics\.com\/analytics\.js/i, /gtag\(/i, /UA-[0-9]+-[0-9]+/i, /G-[A-Z0-9]+/i], meta: [], headers: {} } },
  { name: 'Google Tag Manager', category: 'Analytics',confidence: 'High', patterns: { html: [/googletagmanager\.com/i, /GTM-[A-Z0-9]+/i], meta: [], headers: {} } },
  { name: 'Hotjar',         category: 'Analytics',   confidence: 'High',   patterns: { html: [/hotjar\.com/i, /hjid/i], meta: [], headers: {} } },
  { name: 'Mixpanel',       category: 'Analytics',   confidence: 'High',   patterns: { html: [/mixpanel/i], meta: [], headers: {} } },
  // Payment
  { name: 'Stripe',         category: 'Payment',     confidence: 'High',   patterns: { html: [/js\.stripe\.com/i, /pk_(test|live)_/i], meta: [], headers: {} } },
  { name: 'PayPal',         category: 'Payment',     confidence: 'High',   patterns: { html: [/paypal\.com\/sdk/i, /paypalobjects\.com/i], meta: [], headers: {} } },
  { name: 'Razorpay',       category: 'Payment',     confidence: 'High',   patterns: { html: [/razorpay/i, /checkout\.razorpay/i], meta: [], headers: {} } },
  // Chat / Support
  { name: 'Intercom',       category: 'Chat',        confidence: 'High',   patterns: { html: [/intercom/i, /intercomcdn/i], meta: [], headers: {} } },
  { name: 'Crisp',          category: 'Chat',        confidence: 'High',   patterns: { html: [/crisp\.chat/i, /CRISP_WEBSITE_ID/i], meta: [], headers: {} } },
  { name: 'Zendesk',        category: 'Chat',        confidence: 'High',   patterns: { html: [/zendesk\.com/i, /zopim/i], meta: [], headers: {} } },
  { name: 'LiveChat',       category: 'Chat',        confidence: 'High',   patterns: { html: [/livechatinc\.com/i], meta: [], headers: {} } },
  // Video
  { name: 'YouTube Player', category: 'Media',       confidence: 'High',   patterns: { html: [/youtube\.com\/embed/i, /youtube-nocookie\.com/i], meta: [], headers: {} } },
  { name: 'Vimeo',          category: 'Media',       confidence: 'High',   patterns: { html: [/vimeo\.com\/video/i, /player\.vimeo\.com/i], meta: [], headers: {} } },
  { name: 'JW Player',      category: 'Media',       confidence: 'High',   patterns: { html: [/jwplayer/i, /jwpcdn/i], meta: [], headers: {} } },
  { name: 'Video.js',       category: 'Media',       confidence: 'High',   patterns: { html: [/videojs/i, /video-js/i], meta: [], headers: {} } },
  { name: 'HLS.js',         category: 'Media',       confidence: 'High',   patterns: { scripts: [/hls(?:\.min)?\.js/i], html: [/Hls\(/i], meta: [], headers: {} } },
  { name: 'Dash.js',        category: 'Media',       confidence: 'High',   patterns: { scripts: [/dash(?:\.min)?\.js/i], html: [], meta: [], headers: {} } },
  // Language
  { name: 'PHP',            category: 'Language',    confidence: 'High',   patterns: { html: [], headers: { 'x-powered-by': /php\/([0-9.]+)/i } }, versionRe: /php\/([0-9.]+)/i, headerKey: 'x-powered-by' },
  // Security
  { name: 'reCAPTCHA',      category: 'Security',    confidence: 'High',   patterns: { html: [/recaptcha/i, /google\.com\/recaptcha/i], meta: [], headers: {} } },
  { name: 'hCaptcha',       category: 'Security',    confidence: 'High',   patterns: { html: [/hcaptcha\.com/i], meta: [], headers: {} } },
  { name: 'Cloudflare Turnstile', category: 'Security', confidence: 'High',patterns: { html: [/challenges\.cloudflare\.com/i, /turnstile/i], meta: [], headers: {} } },
  // Fonts
  { name: 'Google Fonts',   category: 'Fonts',       confidence: 'High',   patterns: { html: [/fonts\.googleapis\.com/i], meta: [], headers: {} } },
  { name: 'Font Awesome',   category: 'Fonts',       confidence: 'High',   patterns: { html: [/font-awesome/i, /fontawesome/i], meta: [], links: [/font-awesome/i, /fontawesome/i], headers: {} } },
];

async function detect(url, options = {}) {
  const config = await getAxiosConfig({ ...options, timeout: 15000 });
  const res = await axios.get(url, config);
  const html = typeof res.data === 'string' ? res.data : '';
  const headers = res.headers || {};
  const $ = cheerio.load(html);

  const detected = [];

  // Get script srcs and link hrefs for matching
  const scriptSrcs = [];
  $('script[src]').each((_, el) => scriptSrcs.push($(el).attr('src') || ''));
  const linkHrefs = [];
  $('link[href]').each((_, el) => linkHrefs.push($(el).attr('href') || ''));
  const cookieHeader = headers['set-cookie'] ? (Array.isArray(headers['set-cookie']) ? headers['set-cookie'].join(';') : headers['set-cookie']) : '';
  const metaContent = $('meta').toArray().map(el => Object.values(el.attribs || {}).join(' ')).join(' ');

  for (const tech of TECH_DB) {
    let matched = false;
    let version = null;

    const p = tech.patterns;

    // Check HTML patterns
    if (!matched && p.html) {
      for (const re of p.html) {
        if (re.test(html)) { matched = true; break; }
      }
    }

    // Check meta content
    if (!matched && p.meta) {
      for (const re of p.meta) {
        if (re.test(metaContent)) { matched = true; break; }
      }
    }

    // Check response headers
    if (!matched && p.headers) {
      for (const [hKey, hRe] of Object.entries(p.headers)) {
        const hVal = headers[hKey] || '';
        if (hRe.test(hVal)) {
          matched = true;
          if (tech.versionRe && hKey === tech.headerKey) {
            const vm = hVal.match(tech.versionRe);
            if (vm) version = vm[1];
          }
          break;
        }
      }
    }

    // Check scripts
    if (!matched && p.scripts) {
      for (const re of p.scripts) {
        const found = scriptSrcs.find(s => re.test(s));
        if (found) {
          matched = true;
          if (tech.versionRe) {
            const vm = found.match(tech.versionRe);
            if (vm) version = vm[1];
          }
          break;
        }
      }
    }

    // Check link hrefs
    if (!matched && p.links) {
      for (const re of p.links) {
        if (linkHrefs.find(l => re.test(l))) { matched = true; break; }
      }
    }

    // Check cookies
    if (!matched && p.cookies) {
      for (const re of p.cookies) {
        if (re.test(cookieHeader)) { matched = true; break; }
      }
    }

    if (matched) {
      // Try to extract version from HTML if not found
      if (!version && tech.versionRe) {
        const vm = html.match(tech.versionRe);
        if (vm) version = vm[1];
      }
      detected.push({ name: tech.name, category: tech.category, confidence: tech.confidence, version: version || null });
    }
  }

  // Group by category
  const grouped = {};
  detected.forEach(t => {
    if (!grouped[t.category]) grouped[t.category] = [];
    grouped[t.category].push(t);
  });

  // Count by category
  const categoryCounts = {};
  detected.forEach(t => { categoryCounts[t.category] = (categoryCounts[t.category] || 0) + 1; });

  return {
    totalDetected: detected.length,
    detected,
    grouped,
    categoryCounts,
    rawHeaders: {
      server: headers['server'] || null,
      poweredBy: headers['x-powered-by'] || null,
      via: headers['via'] || null,
    },
  };
}

module.exports = { detect };
