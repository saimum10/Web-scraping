const axios = require('axios');
const { getAxiosConfig } = require('../utils/proxyManager');

async function analyze(url, options = {}) {
  const config = await getAxiosConfig({ ...options, timeout: 15000 });
  const res = await axios.get(url, { ...config, validateStatus: () => true });
  const h = res.headers;
  const server = h['server'] || 'Hidden';
  const poweredBy = h['x-powered-by'] || 'Hidden';
  let framework = 'Unknown';
  if (poweredBy.toLowerCase().includes('php')) framework = `PHP (${poweredBy})`;
  else if (poweredBy.toLowerCase().includes('express')) framework = 'Node.js/Express';
  else if (poweredBy.toLowerCase().includes('asp.net')) framework = 'ASP.NET';
  else if (server.toLowerCase().includes('nginx')) framework = 'Nginx';
  else if (server.toLowerCase().includes('apache')) framework = 'Apache';
  else if (server.toLowerCase().includes('cloudflare')) framework = 'Cloudflare';
  else if (server.toLowerCase().includes('iis')) framework = 'IIS';

  const secHeaderList = [
    { key: 'strict-transport-security', name: 'HSTS', desc: 'HTTPS বাধ্যতামূলক করে' },
    { key: 'content-security-policy', name: 'CSP', desc: 'XSS রোধ করে' },
    { key: 'x-frame-options', name: 'X-Frame-Options', desc: 'Clickjacking রোধ' },
    { key: 'x-content-type-options', name: 'X-Content-Type-Options', desc: 'MIME sniffing রোধ' },
    { key: 'referrer-policy', name: 'Referrer-Policy', desc: 'Referrer নিয়ন্ত্রণ' },
    { key: 'permissions-policy', name: 'Permissions-Policy', desc: 'Browser API নিয়ন্ত্রণ' },
    { key: 'x-xss-protection', name: 'X-XSS-Protection', desc: 'XSS ফিল্টার' },
  ];

  const securityHeaders = secHeaderList.map(sh => ({
    ...sh, present: !!h[sh.key], value: h[sh.key] || null, rating: h[sh.key] ? 'good' : 'missing',
  }));

  const presentCount = securityHeaders.filter(s => s.present).length;
  const securityScore = Math.round((presentCount / secHeaderList.length) * 100);

  const safeHeaders = {};
  Object.keys(h).forEach(k => { if (!['set-cookie'].includes(k)) safeHeaders[k] = h[k]; });

  return {
    statusCode: res.status,
    server, poweredBy, framework,
    isHttps: url.startsWith('https'),
    contentType: h['content-type'] || '',
    securityHeaders,
    securityScore,
    cacheControl: h['cache-control'] || '',
    etag: h['etag'] || '',
    finalUrl: res.request?.res?.responseUrl || url,
    allHeaders: safeHeaders,
    summary: { securityScore: `${securityScore}%`, rating: securityScore >= 70 ? 'ভালো 🟢' : securityScore >= 40 ? 'মাঝারি 🟡' : 'দুর্বল 🔴' },
  };
}

module.exports = { analyze };
