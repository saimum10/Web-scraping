// metaScraper.js
const axios = require('axios');
const cheerio = require('cheerio');
const { getAxiosConfig } = require('../utils/proxyManager');

async function scrape(url, options = {}) {
  const config = await getAxiosConfig({ ...options, timeout: 15000 });
  const res = await axios.get(url, config);
  const $ = cheerio.load(res.data);
  const seo = {
    title: $('title').text().trim(),
    description: $('meta[name="description"]').attr('content') || '',
    keywords: $('meta[name="keywords"]').attr('content') || '',
    robots: $('meta[name="robots"]').attr('content') || '',
    canonical: $('link[rel="canonical"]').attr('href') || '',
    author: $('meta[name="author"]').attr('content') || '',
    viewport: $('meta[name="viewport"]').attr('content') || '',
    language: $('html').attr('lang') || '',
    charset: $('meta[charset]').attr('charset') || '',
  };
  const og = {};
  $('meta[property^="og:"]').each((_, el) => { og[$(el).attr('property').replace('og:', '')] = $(el).attr('content') || ''; });
  const twitter = {};
  $('meta[name^="twitter:"]').each((_, el) => { twitter[$(el).attr('name').replace('twitter:', '')] = $(el).attr('content') || ''; });
  const schemas = [];
  $('script[type="application/ld+json"]').each((_, el) => {
    try { schemas.push(JSON.parse($(el).html())); } catch (_) {}
  });
  const allMeta = [];
  $('meta').each((_, el) => {
    const a = {};
    Object.keys(el.attribs || {}).forEach(k => a[k] = el.attribs[k]);
    if (Object.keys(a).length > 0) allMeta.push(a);
  });
  return { seo, og, twitter, schemas, allMeta: allMeta.slice(0, 60) };
}

module.exports = { scrape };
