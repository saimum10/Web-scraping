const dns = require('dns').promises;
const axios = require('axios');

function extractDomain(url) {
  try {
    const u = new URL(url.startsWith('http') ? url : `https://${url}`);
    const parts = u.hostname.split('.');
    if (parts.length > 2) return parts.slice(-2).join('.');
    return u.hostname;
  } catch (_) { return url.replace(/^https?:\/\//, '').split('/')[0]; }
}

async function safeResolve(hostname) {
  try {
    const ips = await dns.resolve4(hostname);
    return { hostname, ips, active: true };
  } catch (_) { return null; }
}

// Common subdomain wordlist (300+ common subdomains)
const COMMON_SUBDOMAINS = [
  'www', 'api', 'admin', 'mail', 'email', 'smtp', 'pop', 'imap', 'ftp',
  'dev', 'development', 'staging', 'stage', 'test', 'testing', 'demo',
  'beta', 'alpha', 'sandbox', 'preprod', 'prod', 'production', 'live',
  'app', 'apps', 'application', 'portal', 'dashboard', 'panel', 'control',
  'cpanel', 'whm', 'webmail', 'autoconfig', 'autodiscover',
  'ns', 'ns1', 'ns2', 'ns3', 'dns', 'dns1', 'dns2',
  'cdn', 'static', 'assets', 'media', 'img', 'images', 'upload', 'uploads',
  'files', 'download', 'downloads', 'backup', 'backups', 'store',
  'shop', 'cart', 'checkout', 'payment', 'pay', 'billing', 'invoice',
  'docs', 'doc', 'documentation', 'help', 'support', 'kb', 'wiki',
  'blog', 'news', 'forum', 'community', 'status', 'monitor', 'health',
  'metrics', 'analytics', 'tracking', 'stats', 'data',
  'auth', 'login', 'signin', 'signup', 'register', 'account', 'user', 'users',
  'secure', 'ssl', 'vpn', 'remote', 'internal', 'intranet', 'extranet',
  'mobile', 'm', 'wap', 'old', 'new', 'legacy', 'v1', 'v2', 'v3',
  'ci', 'cd', 'git', 'gitlab', 'github', 'bitbucket', 'jenkins', 'jira',
  'confluence', 'sonar', 'grafana', 'kibana', 'elasticsearch',
  'redis', 'mysql', 'db', 'database', 'mongo', 'postgres', 'sql',
  'aws', 'azure', 'gcp', 'cloud', 'k8s', 'kubernetes', 'docker',
  'mail2', 'mail3', 'smtp2', 'mta', 'mx', 'mx1', 'mx2',
  'vpn2', 'proxy', 'gateway', 'lb', 'loadbalancer',
  'ws', 'websocket', 'socket', 'io', 'stream', 'streaming', 'live',
  'video', 'audio', 'media2', 'tv', 'radio',
  'management', 'manage', 'manager', 'backend', 'frontend',
  'office', 'hr', 'crm', 'erp', 'inventory', 'reports',
  'research', 'labs', 'lab', 'experiments', 'prototype',
  'partner', 'partners', 'affiliate', 'affiliates', 'reseller',
  'client', 'clients', 'customer', 'customers', 'vendor', 'vendors',
  'api2', 'api-v2', 'rest', 'graphql', 'grpc', 'rpc',
  'jobs', 'careers', 'about', 'contact',
  'preview', 'uat', 'qa', 'training', 'learn', 'learning',
];

async function find(url, options = {}) {
  const domain = extractDomain(url);
  const results = [];
  const errors = [];

  // 1. Certificate Transparency Logs (crt.sh) — finds real subdomains
  let ctSubdomains = [];
  try {
    const ctRes = await axios.get(`https://crt.sh/?q=%.${domain}&output=json`, { timeout: 15000 });
    if (Array.isArray(ctRes.data)) {
      const names = new Set();
      ctRes.data.forEach(cert => {
        const name = cert.name_value || cert.common_name || '';
        name.split('\n').forEach(n => {
          const clean = n.trim().replace(/^\*\./, '').toLowerCase();
          if (clean.endsWith(`.${domain}`) && !clean.includes('*')) {
            names.add(clean);
          }
        });
      });
      ctSubdomains = [...names];
    }
  } catch (e) {
    errors.push({ source: 'crt.sh', error: e.message });
  }

  // 2. DNS brute-force with common wordlist
  const bruteSubdomains = COMMON_SUBDOMAINS.map(sub => `${sub}.${domain}`);

  // Combine all candidates (deduplicated)
  const allCandidates = [...new Set([...ctSubdomains, ...bruteSubdomains])];

  // 3. DNS resolve all candidates in parallel batches
  const batchSize = 20;
  for (let i = 0; i < Math.min(allCandidates.length, 300); i += batchSize) {
    const batch = allCandidates.slice(i, i + batchSize);
    const resolvedBatch = await Promise.all(batch.map(safeResolve));
    resolvedBatch.forEach(r => {
      if (r) {
        results.push({
          subdomain: r.hostname,
          ip: r.ips?.[0] || null,
          allIps: r.ips || [],
          active: r.active,
          type: ctSubdomains.includes(r.hostname) ? 'CT Log' : 'DNS Brute',
        });
      }
    });
  }

  // 4. Check HTTP status of found subdomains (top 30)
  const statusResults = [];
  for (const sub of results.slice(0, 30)) {
    try {
      const r = await axios.get(`https://${sub.subdomain}`, {
        timeout: 5000,
        validateStatus: () => true,
        maxRedirects: 2,
        headers: { 'User-Agent': 'Mozilla/5.0 (compatible; SubdomainBot/1.0)' },
      });
      statusResults.push({ ...sub, httpStatus: r.status, title: r.data?.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1]?.trim() || null, server: r.headers?.server || null });
    } catch (_) {
      statusResults.push({ ...sub, httpStatus: null });
    }
  }

  // Merge status results
  const finalResults = results.map(r => {
    const sr = statusResults.find(s => s.subdomain === r.subdomain);
    return sr || r;
  });

  // Sort: active first, then by subdomain name
  finalResults.sort((a, b) => (b.active ? 1 : 0) - (a.active ? 1 : 0));

  return {
    domain,
    totalFound: finalResults.length,
    ctLogFindings: ctSubdomains.length,
    bruteForceFindings: finalResults.filter(r => r.type === 'DNS Brute').length,
    found: finalResults,
    errors,
  };
}

module.exports = { find };
