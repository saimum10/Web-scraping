const axios = require('axios');
const cheerio = require('cheerio');
const { getAxiosConfig } = require('../utils/proxyManager');

async function scrape(url, options = {}) {
  const config = await getAxiosConfig({ ...options, timeout: 15000 });
  const res = await axios.get(url, config);
  const $ = cheerio.load(res.data);

  const links = [];
  $('a[href]').each((_, el) => {
    const href = $(el).attr('href');
    if (href && !href.startsWith('#') && !href.startsWith('javascript:')) {
      try { links.push({ text: $(el).text().trim().slice(0, 80), href: new URL(href, url).href }); } catch (_) {}
    }
  });

  const images = [];
  $('img, source').each((_, el) => {
    const src = $(el).attr('src') || $(el).attr('data-src') || $(el).attr('srcset')?.split(' ')[0];
    if (src) {
      try { images.push({ src: new URL(src, url).href, alt: ($(el).attr('alt') || '').slice(0, 100) }); } catch (_) {}
    }
  });

  const tables = [];
  $('table').each((_, table) => {
    const rows = [];
    $(table).find('tr').each((_, tr) => {
      const cells = [];
      $(tr).find('th,td').each((_, td) => cells.push($(td).text().trim().slice(0, 100)));
      if (cells.length) rows.push(cells);
    });
    if (rows.length) tables.push(rows);
  });

  const scripts = [];
  $('script[src]').each((_, el) => {
    try { scripts.push(new URL($(el).attr('src'), url).href); } catch (_) {}
  });

  const forms = [];
  $('form').each((_, form) => {
    const inputs = [];
    $(form).find('input,select,textarea,button[type=submit]').each((_, inp) => {
      inputs.push({ name: $(inp).attr('name') || '', type: $(inp).attr('type') || $(inp).prop('tagName').toLowerCase(), placeholder: $(inp).attr('placeholder') || '', value: $(inp).attr('value') || '' });
    });
    forms.push({ action: $(form).attr('action') || '', method: ($(form).attr('method') || 'GET').toUpperCase(), inputs, enctype: $(form).attr('enctype') || '' });
  });

  const headings = [];
  $('h1,h2,h3,h4,h5').each((_, el) => headings.push({ tag: el.tagName, text: $(el).text().trim().slice(0, 120) }));

  const emails = [];
  const emailRe = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
  const bodyText = $('body').text();
  const emailMatches = bodyText.match(emailRe) || [];
  emails.push(...[...new Set(emailMatches)].slice(0, 20));

  const phoneRe = /(?:\+?88)?01[3-9]\d{8}/g;
  const phones = [...new Set((bodyText.match(phoneRe) || []))].slice(0, 10);

  return {
    title: $('title').text().trim(),
    links: links.slice(0, 100),
    images: images.slice(0, 50),
    tables: tables.slice(0, 10),
    scripts: scripts.slice(0, 30),
    forms,
    headings: headings.slice(0, 30),
    emails,
    phones,
    bodyTextPreview: bodyText.replace(/\s+/g, ' ').trim().slice(0, 3000),
    counts: { links: links.length, images: images.length, tables: tables.length, scripts: scripts.length, forms: forms.length, emails: emails.length },
  };
}

module.exports = { scrape };
