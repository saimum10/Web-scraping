// analyticsScraper.js
const axios = require('axios');
const { getAxiosConfig } = require('../utils/proxyManager');

async function find(url, options = {}) {
  const config = await getAxiosConfig({ ...options, timeout: 15000 });
  const res = await axios.get(url, config);
  const html = typeof res.data === 'string' ? res.data : '';
  const results = {};
  const checks = [
    ['Google Analytics (UA)', /UA-\d{4,12}-\d{1,3}/g],
    ['Google Analytics (GA4)', /G-[A-Z0-9]{8,12}/g],
    ['Google Tag Manager', /GTM-[A-Z0-9]{5,8}/g],
    ['Google AdSense', /ca-pub-\d{10,18}/g],
    ['Facebook Pixel', /fbq\s*\(\s*['"]init['"]\s*,\s*['"](\d{10,20})['"]/g],
    ['Facebook App ID', /"app_id"\s*:\s*"(\d{10,20})"/g],
    ['Hotjar', /hjid\s*[=:]\s*(\d{4,8})/g],
    ['Stripe', /pk_(test|live)_[A-Za-z0-9]{20,50}/g],
    ['reCAPTCHA Key', /6[A-Za-z0-9_-]{39}/g],
    ['TikTok Pixel', /ttq\.load\s*\(\s*['"]([A-Z0-9]{20})['"]/g],
    ['YouTube Channel', /youtube\.com\/channel\/([A-Za-z0-9_-]{24})/g],
    ['YouTube Video', /youtube\.com\/embed\/([A-Za-z0-9_-]{11})/g],
    ['Segment', /analytics\.load\s*\(\s*['"]([A-Za-z0-9]{20,30})['"]/g],
    ['Intercom', /app_id\s*:\s*['"]([a-z0-9]{8,12})['"]/g],
    ['Crisp', /CRISP_WEBSITE_ID\s*=\s*['"]([a-f0-9-]{36})['"]/g],
    ['Mixpanel', /mixpanel\.init\s*\(\s*['"]([a-f0-9]{32})['"]/g],
    ['Cloudflare', /cloudflare-static|cdn-cgi\/challenge/g],
    ['Mailchimp', /mailchimp\.com\/[a-z0-9-]+/g],
    ['Disqus', /disqus\.com\/embed/g],
  ];
  checks.forEach(([key, re]) => {
    const matches = [...html.matchAll(new RegExp(re.source, re.flags))];
    if (matches.length) {
      const unique = [...new Set(matches.map(m => m[1] || m[0]))].slice(0, 10);
      results[key] = unique;
    }
  });
  return { found: Object.keys(results).length, trackers: results };
}
module.exports = { find };
