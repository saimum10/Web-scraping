const axios = require('axios');
const cheerio = require('cheerio');

async function fetch(url) {
  const base = new URL(url.startsWith('http') ? url : `https://${url}`).origin;
  const H = { 'User-Agent': 'Mozilla/5.0 (compatible; WebScrapingBot/3.0)' };

  let robots = { content: null, disallowed: [], allowed: [], sitemaps: [], crawlDelay: null };
  try {
    const r = await axios.get(`${base}/robots.txt`, { headers: H, timeout: 8000, validateStatus: () => true });
    if (r.status === 200 && typeof r.data === 'string') {
      robots.content = r.data.slice(0, 5000);
      r.data.split('\n').forEach(line => {
        const l = line.trim();
        const lower = l.toLowerCase();
        if (lower.startsWith('disallow:')) robots.disallowed.push(l.slice(10).trim());
        else if (lower.startsWith('allow:')) robots.allowed.push(l.slice(7).trim());
        else if (lower.startsWith('sitemap:')) robots.sitemaps.push(l.slice(8).trim());
        else if (lower.startsWith('crawl-delay:')) robots.crawlDelay = l.slice(12).trim();
      });
      robots.disallowed = robots.disallowed.filter(Boolean).slice(0, 100);
      robots.allowed = robots.allowed.filter(Boolean).slice(0, 50);
    }
  } catch (_) {}

  let sitemap = { found: false, urls: [], count: 0 };
  const sUrls = robots.sitemaps.length ? robots.sitemaps : [`${base}/sitemap.xml`, `${base}/sitemap_index.xml`];
  for (const sUrl of sUrls.slice(0, 3)) {
    try {
      const r = await axios.get(sUrl, { headers: H, timeout: 8000, validateStatus: () => true });
      if (r.status === 200) {
        const $ = cheerio.load(r.data, { xmlMode: true });
        sitemap.found = true;
        $('url loc, sitemap loc').each((_, el) => sitemap.urls.push($(el).text().trim()));
        sitemap.count = sitemap.urls.length;
        sitemap.urls = sitemap.urls.slice(0, 200);
        break;
      }
    } catch (_) {}
  }

  let securityTxt = null;
  try {
    const r = await axios.get(`${base}/.well-known/security.txt`, { headers: H, timeout: 5000, validateStatus: () => true });
    if (r.status === 200) securityTxt = String(r.data).slice(0, 1000);
  } catch (_) {}

  return { robots, sitemap, securityTxt };
}
module.exports = { fetch };
