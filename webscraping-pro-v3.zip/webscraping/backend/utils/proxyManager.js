const axios = require('axios');
const { HttpsProxyAgent } = require('https-proxy-agent');

let proxyList = [];
let proxyIndex = 0;
let lastFetch = 0;

// Free proxy sources
const PROXY_SOURCES = [
  'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=5000&country=all&ssl=all&anonymity=anonymous',
  'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
  'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt',
];

async function fetchProxies() {
  const now = Date.now();
  // Refresh every 10 minutes
  if (proxyList.length > 0 && now - lastFetch < 600000) return proxyList;

  const newProxies = [];
  for (const source of PROXY_SOURCES) {
    try {
      const res = await axios.get(source, { timeout: 8000 });
      const lines = res.data.split('\n').map(l => l.trim()).filter(l => /^\d+\.\d+\.\d+\.\d+:\d+$/.test(l));
      newProxies.push(...lines.slice(0, 50));
      if (newProxies.length > 30) break;
    } catch (_) {}
  }

  if (newProxies.length > 0) {
    proxyList = [...new Set(newProxies)];
    lastFetch = now;
  }
  return proxyList;
}

async function getNextProxy() {
  const list = await fetchProxies();
  if (list.length === 0) return null;
  proxyIndex = (proxyIndex + 1) % list.length;
  return list[proxyIndex];
}

async function getAxiosConfig(options = {}) {
  const config = {
    timeout: options.timeout || 15000,
    headers: {
      'User-Agent': getRandomUA(),
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9',
      'Accept-Encoding': 'gzip, deflate, br',
      'DNT': '1',
      'Connection': 'keep-alive',
      'Upgrade-Insecure-Requests': '1',
      ...(options.headers || {}),
    },
    validateStatus: () => true,
    maxRedirects: 5,
  };

  // Add custom cookies
  if (options.cookies) {
    config.headers['Cookie'] = options.cookies;
  }

  // Add proxy if enabled
  if (options.useProxy) {
    const proxy = await getNextProxy();
    if (proxy) {
      const agent = new HttpsProxyAgent(`http://${proxy}`);
      config.httpAgent = agent;
      config.httpsAgent = agent;
      config._proxyUsed = proxy;
    }
  }

  return config;
}

// Smart delay - random human-like
function smartDelay(min = 500, max = 2000) {
  const ms = Math.floor(Math.random() * (max - min) + min);
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Check if site needs delay (based on response headers)
function needsDelay(headers) {
  const rateLimitHeaders = ['x-ratelimit-limit', 'x-rate-limit', 'retry-after', 'x-ratelimit-remaining'];
  return rateLimitHeaders.some(h => headers[h] !== undefined);
}

const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
  'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
];

function getRandomUA() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

async function getProxyList() {
  return await fetchProxies();
}

module.exports = { getAxiosConfig, smartDelay, needsDelay, getProxyList, getRandomUA };
