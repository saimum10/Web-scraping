const PDFDocument = require('pdfkit');

// ── JSON Export ────────────────────────────────────────────────────────────
function exportJSON(scanData) {
  return JSON.stringify(scanData, null, 2);
}

// ── CSV Export ─────────────────────────────────────────────────────────────
function exportCSV(scanData) {
  const rows = [];
  const url = scanData.url || '';

  rows.push(['Category', 'Type', 'Key', 'Value', 'Notes']);

  // HTML
  const html = scanData.results?.html;
  if (html) {
    (html.links || []).slice(0, 50).forEach(l => rows.push(['HTML', 'Link', l.text || '-', l.href, '']));
    (html.images || []).slice(0, 30).forEach(i => rows.push(['HTML', 'Image', i.alt || '-', i.src, '']));
    (html.forms || []).forEach(f => rows.push(['HTML', 'Form', f.method, f.action, `${f.inputs?.length || 0} inputs`]));
  }

  // APIs
  const api = scanData.results?.api;
  if (api) {
    (api.xhrPatterns || []).forEach(x => rows.push(['API', 'XHR Endpoint', x.method, x.endpoint, '']));
    (api.streamingApis || []).forEach(s => rows.push(['API', `Streaming (${s.type})`, s.label || '-', s.url, '']));
    (api.probeResults || []).filter(p => p.interesting).forEach(p => rows.push(['API', 'Probe', p.status, p.path, p.contentType || '']));
  }

  // JS Keys
  const js = scanData.results?.js;
  if (js) {
    Object.entries(js.summary || {}).forEach(([label, info]) => {
      (info.matches || []).forEach(m => rows.push(['JS Audit', label, '-', m, `Found ${info.count}x`]));
    });
  }

  // DNS
  const dns = scanData.results?.dns;
  if (dns) {
    (dns.ipv4 || []).forEach(ip => rows.push(['DNS', 'IPv4', 'A Record', ip, '']));
    (dns.nameservers || []).forEach(ns => rows.push(['DNS', 'Nameserver', 'NS', ns, '']));
    (dns.mx || []).forEach(mx => rows.push(['DNS', 'Mail Server', 'MX', mx.exchange, `Priority: ${mx.priority}`]));
    (dns.txt || []).forEach(t => rows.push(['DNS', 'TXT Record', '-', t, '']));
  }

  // Subdomains
  const sub = scanData.results?.subdomains;
  if (sub) {
    (sub.found || []).forEach(s => rows.push(['Subdomain', s.type || 'found', s.subdomain, s.ip || '-', s.status || '']));
  }

  // Tech
  const tech = scanData.results?.tech;
  if (tech) {
    (tech.detected || []).forEach(t => rows.push(['Technology', t.category, t.name, t.version || '-', t.confidence || '']));
  }

  // Cookies
  const cookies = scanData.results?.cookies;
  if (cookies) {
    (cookies.cookies || []).forEach(c => rows.push(['Cookie', c.type || 'General', c.name, c.value?.slice(0, 80) || '', c.securityIssues?.join('; ') || 'OK']));
  }

  // Security
  const sec = scanData.results?.security;
  if (sec) {
    rows.push(['Security', 'Server', 'Server Header', sec.server || '-', '']);
    rows.push(['Security', 'Framework', 'X-Powered-By', sec.poweredBy || '-', '']);
    rows.push(['Security', 'Score', 'Security Score', `${sec.securityScore || 0}%`, sec.summary?.rating || '']);
    (sec.securityHeaders || []).forEach(h => rows.push(['Security', 'Header', h.name, h.present ? h.value || 'Present' : 'MISSING', h.present ? '✓' : '✗']));
  }

  // Dir Bruteforce
  const dir = scanData.results?.directories;
  if (dir) {
    (dir.found || []).forEach(d => rows.push(['Directory', 'Found', d.status, d.path, d.contentType || '']));
  }

  return rows.map(row =>
    row.map(cell => `"${String(cell || '').replace(/"/g, '""')}"`).join(',')
  ).join('\n');
}

// ── Markdown Export ────────────────────────────────────────────────────────
function exportMarkdown(scanData) {
  const url = scanData.url || 'Unknown';
  const ts = new Date(scanData.timestamp || Date.now()).toLocaleString();
  let md = `# 🕷️ Web Scraping Report\n\n`;
  md += `**Target:** \`${url}\`  \n**Date:** ${ts}\n\n---\n\n`;

  const r = scanData.results || {};

  if (r.security) {
    md += `## 🛡️ Security\n`;
    md += `- **Server:** ${r.security.server || 'Hidden'}\n`;
    md += `- **Framework:** ${r.security.framework || 'Unknown'}\n`;
    md += `- **Security Score:** ${r.security.securityScore || 0}%\n`;
    md += `- **HTTPS:** ${r.security.isHttps ? 'Yes ✅' : 'No ❌'}\n\n`;
    if (r.security.securityHeaders?.length) {
      md += `### Security Headers\n`;
      r.security.securityHeaders.forEach(h => {
        md += `- ${h.present ? '✅' : '❌'} **${h.name}**${h.value ? `: \`${h.value.slice(0,60)}\`` : ''}\n`;
      });
      md += '\n';
    }
  }

  if (r.tech?.detected?.length) {
    md += `## 🔧 Technology Stack\n`;
    const grouped = {};
    r.tech.detected.forEach(t => {
      if (!grouped[t.category]) grouped[t.category] = [];
      grouped[t.category].push(t);
    });
    Object.entries(grouped).forEach(([cat, items]) => {
      md += `### ${cat}\n`;
      items.forEach(t => md += `- **${t.name}** ${t.version ? `v${t.version}` : ''} (${t.confidence})\n`);
    });
    md += '\n';
  }

  if (r.js && Object.keys(r.js.summary || {}).length) {
    md += `## ⚙️ JS Audit Findings\n`;
    Object.entries(r.js.summary).forEach(([label, info]) => {
      md += `### ${label} (${info.count} found)\n`;
      info.matches.slice(0, 5).forEach(m => md += `- \`${m}\`\n`);
    });
    md += '\n';
  }

  if (r.api) {
    md += `## 🔌 API Endpoints\n`;
    if (r.api.streamingApis?.length) {
      md += `### Streaming APIs\n`;
      r.api.streamingApis.forEach(s => md += `- **[${s.type}]** \`${s.url}\`\n`);
      md += '\n';
    }
    if (r.api.xhrPatterns?.length) {
      md += `### XHR/Fetch\n`;
      r.api.xhrPatterns.slice(0, 20).forEach(x => md += `- \`${x.method}\` \`${x.endpoint}\`\n`);
      md += '\n';
    }
  }

  if (r.subdomains?.found?.length) {
    md += `## 🌐 Subdomains\n`;
    r.subdomains.found.forEach(s => md += `- \`${s.subdomain}\` → ${s.ip || 'Unknown'}\n`);
    md += '\n';
  }

  if (r.dns) {
    md += `## 🔍 DNS\n`;
    md += `- **IP:** ${r.dns.ipv4?.join(', ') || '-'}\n`;
    md += `- **CDN:** ${r.dns.cdn || '-'}\n`;
    md += `- **Nameservers:** ${r.dns.nameservers?.join(', ') || '-'}\n\n`;
  }

  return md;
}

// ── HTML Report ────────────────────────────────────────────────────────────
function exportHTML(scanData) {
  const url = scanData.url || 'Unknown';
  const ts = new Date(scanData.timestamp || Date.now()).toLocaleString();
  const r = scanData.results || {};

  const sec = r.security;
  const scoreColor = sec ? (sec.securityScore >= 70 ? '#00d084' : sec.securityScore >= 40 ? '#ffd700' : '#ff4757') : '#888';

  const sectionStyle = 'background:#1a1a2e;border:1px solid #ffffff15;border-radius:12px;padding:20px;margin-bottom:16px;';
  const hStyle = 'color:#00d4ff;font-family:monospace;font-size:14px;margin:0 0 12px;letter-spacing:1px;';
  const rowStyle = 'display:flex;gap:12px;padding:5px 0;border-bottom:1px solid #ffffff08;font-size:12px;';
  const labelStyle = 'color:#ffffff44;min-width:140px;flex-shrink:0;';
  const valueStyle = 'color:#e0e0ff;word-break:break-all;font-family:monospace;';

  let sections = '';

  if (sec) {
    sections += `<div style="${sectionStyle}">
      <h2 style="${hStyle}">🛡️ SECURITY ANALYSIS</h2>
      <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:12px;">
        <div style="background:#ffffff08;border-radius:8px;padding:10px 16px;text-align:center;">
          <div style="color:${scoreColor};font-size:24px;font-weight:700;">${sec.securityScore || 0}%</div>
          <div style="color:#888;font-size:10px;">Security Score</div>
        </div>
        <div style="background:#ffffff08;border-radius:8px;padding:10px 16px;text-align:center;">
          <div style="color:#00d4ff;font-size:24px;font-weight:700;">${sec.statusCode || '-'}</div>
          <div style="color:#888;font-size:10px;">HTTP Status</div>
        </div>
      </div>
      <div style="${rowStyle}"><span style="${labelStyle}">Server</span><span style="${valueStyle}">${sec.server || 'Hidden'}</span></div>
      <div style="${rowStyle}"><span style="${labelStyle}">Framework</span><span style="${valueStyle}">${sec.framework || 'Unknown'}</span></div>
      <div style="${rowStyle}"><span style="${labelStyle}">HTTPS</span><span style="${valueStyle}">${sec.isHttps ? '✅ Yes' : '❌ No'}</span></div>
      <div style="margin-top:12px;">
        ${(sec.securityHeaders || []).map(h => `
          <div style="${rowStyle}">
            <span style="color:${h.present ? '#00d084' : '#ff4757'};min-width:20px;">${h.present ? '✓' : '✗'}</span>
            <span style="${labelStyle}">${h.name}</span>
            <span style="color:#888;font-size:11px;font-family:monospace;">${h.value ? h.value.slice(0, 60) : (h.present ? 'Present' : 'MISSING')}</span>
          </div>`).join('')}
      </div>
    </div>`;
  }

  if (r.tech?.detected?.length) {
    const grouped = {};
    r.tech.detected.forEach(t => { if (!grouped[t.category]) grouped[t.category] = []; grouped[t.category].push(t); });
    sections += `<div style="${sectionStyle}">
      <h2 style="${hStyle}">🔧 TECHNOLOGY STACK</h2>
      ${Object.entries(grouped).map(([cat, items]) => `
        <div style="margin-bottom:10px;">
          <div style="color:#c77dff;font-size:11px;font-weight:700;margin-bottom:4px;">${cat}</div>
          ${items.map(t => `<span style="display:inline-block;background:#c77dff22;border:1px solid #c77dff44;color:#c77dff;border-radius:20px;padding:3px 10px;margin:2px;font-size:11px;">${t.name}${t.version ? ` v${t.version}` : ''}</span>`).join('')}
        </div>`).join('')}
    </div>`;
  }

  if (r.js && Object.keys(r.js.summary || {}).length) {
    sections += `<div style="${sectionStyle}">
      <h2 style="${hStyle}">⚙️ JS AUDIT — SENSITIVE DATA</h2>
      ${Object.entries(r.js.summary).map(([label, info]) => `
        <div style="margin-bottom:12px;">
          <div style="color:#ff6b7a;font-size:12px;font-weight:700;margin-bottom:4px;">🔑 ${label} <span style="color:#ff475788;font-size:10px;">(${info.count} found)</span></div>
          ${info.matches.slice(0,5).map(m => `<div style="background:#ff475710;border:1px solid #ff475733;border-radius:6px;padding:5px 10px;margin-bottom:3px;font-family:monospace;font-size:11px;color:#ffaaaa;word-break:break-all;">${m}</div>`).join('')}
        </div>`).join('')}
    </div>`;
  }

  if (r.api) {
    let apiContent = '';
    if (r.api.streamingApis?.length) {
      apiContent += `<div style="margin-bottom:12px;"><div style="color:#ffd700;font-size:12px;font-weight:700;margin-bottom:4px;">📺 Streaming APIs</div>${r.api.streamingApis.map(s => `<div style="display:flex;gap:8px;padding:4px 0;border-bottom:1px solid #ffffff05;"><span style="color:#ffd700;font-size:10px;background:#ffd70022;border-radius:4px;padding:1px 6px;">${s.type}</span><span style="color:#e0e0ff;font-family:monospace;font-size:11px;word-break:break-all;">${s.url}</span></div>`).join('')}</div>`;
    }
    if (r.api.xhrPatterns?.length) {
      const methodColor = { GET: '#00d084', POST: '#00d4ff', PUT: '#ffd700', DELETE: '#ff4757', PATCH: '#c77dff' };
      apiContent += `<div style="margin-bottom:12px;"><div style="color:#00d4ff;font-size:12px;font-weight:700;margin-bottom:4px;">📡 XHR/Fetch Calls</div>${r.api.xhrPatterns.slice(0,20).map(x => `<div style="display:flex;gap:8px;padding:4px 0;border-bottom:1px solid #ffffff05;align-items:center;"><span style="color:${methodColor[x.method]||'#888'};font-size:10px;background:${methodColor[x.method]||'#888'}22;border-radius:4px;padding:1px 6px;min-width:45px;text-align:center;">${x.method}</span><span style="color:#e0e0ff;font-family:monospace;font-size:11px;word-break:break-all;">${x.endpoint}</span></div>`).join('')}</div>`;
    }
    if (apiContent) {
      sections += `<div style="${sectionStyle}"><h2 style="${hStyle}">🔌 API DISCOVERY</h2>${apiContent}</div>`;
    }
  }

  if (r.subdomains?.found?.length) {
    sections += `<div style="${sectionStyle}">
      <h2 style="${hStyle}">🌐 SUBDOMAINS (${r.subdomains.found.length} found)</h2>
      ${r.subdomains.found.map(s => `<div style="${rowStyle}"><span style="color:#00d4ff;font-family:monospace;font-size:12px;">${s.subdomain}</span><span style="color:#888;font-size:11px;">→ ${s.ip || 'Unknown'}</span><span style="color:${s.active ? '#00d084' : '#555'};font-size:10px;">${s.active ? '● Live' : '○ Inactive'}</span></div>`).join('')}
    </div>`;
  }

  if (r.directories?.found?.length) {
    sections += `<div style="${sectionStyle}">
      <h2 style="${hStyle}">📂 DIRECTORIES FOUND (${r.directories.found.length})</h2>
      ${r.directories.found.map(d => `<div style="${rowStyle}"><span style="color:${d.status===200?'#00d084':d.status===403?'#ffd700':'#aaa'};font-size:12px;min-width:45px;">${d.status}</span><span style="color:#e0e0ff;font-family:monospace;font-size:12px;">${d.path}</span><span style="color:#666;font-size:10px;">${d.contentType?.split(';')[0]||''}</span></div>`).join('')}
    </div>`;
  }

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Web Scraping Report — ${url}</title>
  <style>
    * { box-sizing: border-box; }
    body { background: #060610; color: #fff; font-family: 'Segoe UI', sans-serif; margin: 0; padding: 20px; }
    ::-webkit-scrollbar { width: 4px; } ::-webkit-scrollbar-thumb { background: #333; }
  </style>
</head>
<body>
  <div style="max-width:900px;margin:0 auto;">
    <div style="background:linear-gradient(90deg,#0d0d1a,#1a0d2e);border:1px solid #ffffff15;border-radius:16px;padding:24px;margin-bottom:20px;">
      <h1 style="margin:0;font-size:24px;background:linear-gradient(90deg,#00d4ff,#c77dff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">🕷️ Web Scraping Report</h1>
      <div style="color:#ffffff44;font-size:12px;margin-top:6px;font-family:monospace;">${url}</div>
      <div style="color:#ffffff33;font-size:11px;margin-top:4px;">Generated: ${ts}</div>
    </div>
    ${sections}
    <div style="text-align:center;color:#ffffff22;font-size:10px;margin-top:20px;">Generated by Web Scraping Pro v3</div>
  </div>
</body>
</html>`;
}

// ── TXT Export ─────────────────────────────────────────────────────────────
function exportTXT(scanData) {
  const url = scanData.url || 'Unknown';
  const ts = new Date(scanData.timestamp || Date.now()).toLocaleString();
  const r = scanData.results || {};
  let txt = `WEB SCRAPING REPORT\n${'='.repeat(60)}\nTarget: ${url}\nDate: ${ts}\n${'='.repeat(60)}\n\n`;

  const sec = r.security;
  if (sec) {
    txt += `SECURITY\n${'-'.repeat(40)}\n`;
    txt += `Server: ${sec.server || 'Hidden'}\n`;
    txt += `Framework: ${sec.framework || 'Unknown'}\n`;
    txt += `Security Score: ${sec.securityScore || 0}%\n`;
    txt += `HTTPS: ${sec.isHttps ? 'Yes' : 'No'}\n`;
    (sec.securityHeaders || []).forEach(h => {
      txt += `[${h.present ? 'OK' : 'MISS'}] ${h.name}${h.value ? ': ' + h.value.slice(0,60) : ''}\n`;
    });
    txt += '\n';
  }

  if (r.tech?.detected?.length) {
    txt += `TECHNOLOGY STACK\n${'-'.repeat(40)}\n`;
    r.tech.detected.forEach(t => txt += `[${t.category}] ${t.name}${t.version ? ' v' + t.version : ''}\n`);
    txt += '\n';
  }

  if (r.js && Object.keys(r.js.summary || {}).length) {
    txt += `JS AUDIT — SENSITIVE FINDINGS\n${'-'.repeat(40)}\n`;
    Object.entries(r.js.summary).forEach(([label, info]) => {
      txt += `\n>> ${label} (${info.count} found)\n`;
      info.matches.slice(0, 5).forEach(m => txt += `   ${m}\n`);
    });
    txt += '\n';
  }

  if (r.api) {
    txt += `API ENDPOINTS\n${'-'.repeat(40)}\n`;
    (r.api.streamingApis || []).forEach(s => txt += `[${s.type}] ${s.url}\n`);
    (r.api.xhrPatterns || []).slice(0, 20).forEach(x => txt += `[${x.method}] ${x.endpoint}\n`);
    txt += '\n';
  }

  if (r.subdomains?.found?.length) {
    txt += `SUBDOMAINS\n${'-'.repeat(40)}\n`;
    r.subdomains.found.forEach(s => txt += `${s.subdomain} → ${s.ip || 'Unknown'}\n`);
    txt += '\n';
  }

  if (r.directories?.found?.length) {
    txt += `DIRECTORIES FOUND\n${'-'.repeat(40)}\n`;
    r.directories.found.forEach(d => txt += `[${d.status}] ${d.path}\n`);
    txt += '\n';
  }

  if (r.dns) {
    txt += `DNS RECORDS\n${'-'.repeat(40)}\n`;
    txt += `IP: ${r.dns.ipv4?.join(', ') || '-'}\n`;
    txt += `NS: ${r.dns.nameservers?.join(', ') || '-'}\n`;
    txt += `CDN: ${r.dns.cdn || '-'}\n`;
    (r.dns.txt || []).forEach(t => txt += `TXT: ${t}\n`);
    txt += '\n';
  }

  return txt;
}

// ── PDF Export ─────────────────────────────────────────────────────────────
function exportPDF(scanData, res) {
  const url = scanData.url || 'Unknown';
  const ts = new Date(scanData.timestamp || Date.now()).toLocaleString();
  const r = scanData.results || {};

  const doc = new PDFDocument({ margin: 40, size: 'A4' });

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="webscraping-report-${Date.now()}.pdf"`);
  doc.pipe(res);

  // Colors
  const BLUE = '#00d4ff';
  const PURPLE = '#c77dff';
  const GREEN = '#00d084';
  const RED = '#ff4757';
  const YELLOW = '#ffd700';

  // Background
  doc.rect(0, 0, 595, 842).fill('#060610');

  // Header
  doc.rect(0, 0, 595, 80).fill('#0d0d1a');
  doc.fontSize(20).fillColor(BLUE).text('Web Scraping Pro', 40, 20, { align: 'left' });
  doc.fontSize(10).fillColor('#aaaaaa').text('Security & OSINT Report', 40, 46);
  doc.fontSize(8).fillColor('#666666').text(ts, 40, 60);

  let y = 100;

  function section(title, color = BLUE) {
    if (y > 750) { doc.addPage(); doc.rect(0, 0, 595, 842).fill('#060610'); y = 40; }
    doc.rect(40, y, 515, 24).fill('#0d0d1a');
    doc.fontSize(10).fillColor(color).text(title, 50, y + 7);
    y += 32;
  }

  function row(label, value, valueColor = '#cccccc') {
    if (y > 780) { doc.addPage(); doc.rect(0, 0, 595, 842).fill('#060610'); y = 40; }
    doc.fontSize(8).fillColor('#888888').text(label, 50, y, { width: 140 });
    doc.fontSize(8).fillColor(valueColor).text(String(value || '-').slice(0, 80), 200, y, { width: 350 });
    doc.rect(40, y + 14, 515, 0.5).fill('#ffffff11');
    y += 18;
  }

  function badge(text, x, yy, color = BLUE) {
    const w = text.length * 6 + 10;
    doc.rect(x, yy - 2, w, 14).fill(color + '33').stroke(color + '66');
    doc.fontSize(7).fillColor(color).text(text, x + 4, yy + 1);
    return x + w + 6;
  }

  // Target URL
  doc.fontSize(9).fillColor('#ffffff44').text('Target URL:', 40, y);
  doc.fontSize(9).fillColor(BLUE).text(url, 120, y, { width: 435 });
  y += 25;

  // Security
  const sec = r.security;
  if (sec) {
    section('SECURITY ANALYSIS', RED);
    row('HTTP Status', sec.statusCode, sec.statusCode === 200 ? GREEN : YELLOW);
    row('Server', sec.server || 'Hidden');
    row('Framework', sec.framework || 'Unknown', PURPLE);
    row('Security Score', `${sec.securityScore || 0}%`, sec.securityScore >= 70 ? GREEN : sec.securityScore >= 40 ? YELLOW : RED);
    row('HTTPS', sec.isHttps ? 'Yes ✓' : 'No ✗', sec.isHttps ? GREEN : RED);
    y += 4;
    (sec.securityHeaders || []).forEach(h => row(h.name, h.present ? (h.value?.slice(0,60) || 'Present') : 'MISSING', h.present ? GREEN : RED));
    y += 8;
  }

  // Tech
  if (r.tech?.detected?.length) {
    section('TECHNOLOGY STACK', PURPLE);
    r.tech.detected.forEach(t => row(`[${t.category}] ${t.name}`, `${t.version ? 'v' + t.version : 'Detected'} — ${t.confidence}`, PURPLE));
    y += 8;
  }

  // JS Audit
  if (r.js && Object.keys(r.js.summary || {}).length) {
    section('JS AUDIT — SENSITIVE DATA', RED);
    Object.entries(r.js.summary).forEach(([label, info]) => {
      row(label, `${info.count} found`, RED);
      info.matches.slice(0, 3).forEach(m => {
        if (y > 780) { doc.addPage(); doc.rect(0, 0, 595, 842).fill('#060610'); y = 40; }
        doc.fontSize(7).fillColor('#ff9999').text(`  → ${m.slice(0, 80)}`, 60, y);
        y += 14;
      });
    });
    y += 8;
  }

  // API
  if (r.api) {
    section('API DISCOVERY', BLUE);
    (r.api.streamingApis || []).forEach(s => row(`[${s.type}]`, s.url.slice(0, 70), YELLOW));
    (r.api.xhrPatterns || []).slice(0, 15).forEach(x => row(`[${x.method}]`, x.endpoint.slice(0, 70), GREEN));
    (r.api.probeResults || []).filter(p => p.interesting).forEach(p => row(`[${p.status}] ${p.path}`, p.contentType || '', p.status === 200 ? GREEN : YELLOW));
    y += 8;
  }

  // Subdomains
  if (r.subdomains?.found?.length) {
    section('SUBDOMAINS', GREEN);
    r.subdomains.found.forEach(s => row(s.subdomain, `→ ${s.ip || 'Unknown'}`, s.active ? GREEN : '#888'));
    y += 8;
  }

  // Directories
  if (r.directories?.found?.length) {
    section('DIRECTORIES FOUND', YELLOW);
    r.directories.found.forEach(d => row(`[${d.status}] ${d.path}`, d.contentType?.split(';')[0] || '', d.status === 200 ? GREEN : YELLOW));
    y += 8;
  }

  // DNS
  if (r.dns) {
    section('DNS RECORDS', '#888888');
    row('IPv4', r.dns.ipv4?.join(', ') || '-');
    row('CDN/Hosting', r.dns.cdn || '-', BLUE);
    row('Nameservers', r.dns.nameservers?.join(', ') || '-');
    if (r.dns.whois) {
      row('Registrar', r.dns.whois.registrar || '-');
      row('Registered', r.dns.whois.registered || '-');
      row('Expires', r.dns.whois.expires || '-');
    }
    y += 8;
  }

  // Footer
  doc.rect(0, 800, 595, 42).fill('#0d0d1a');
  doc.fontSize(7).fillColor('#444444').text('Generated by Web Scraping Pro v3 — For authorized use only', 40, 812, { align: 'center', width: 515 });

  doc.end();
}

module.exports = { exportJSON, exportCSV, exportMarkdown, exportHTML, exportTXT, exportPDF };
