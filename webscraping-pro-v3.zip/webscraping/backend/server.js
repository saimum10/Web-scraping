const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const path = require('path');

const htmlScraper    = require('./scrapers/htmlScraper');
const metaScraper    = require('./scrapers/metaScraper');
const dnsScraper     = require('./scrapers/dnsScraper');
const securityScraper= require('./scrapers/securityScraper');
const analyticsScraper= require('./scrapers/analyticsScraper');
const robotsScraper  = require('./scrapers/robotsScraper');
const jsScraper      = require('./scrapers/jsScraper');
const cookieScraper  = require('./scrapers/cookieScraper');
const apiScraper     = require('./scrapers/apiScraper');
const subdomainFinder= require('./scrapers/subdomainFinder');
const dirBruteforce  = require('./scrapers/dirBruteforce');
const techFingerprint= require('./scrapers/techFingerprint');
const { getProxyList } = require('./utils/proxyManager');
const { exportJSON, exportCSV, exportMarkdown, exportHTML, exportTXT, exportPDF } = require('./utils/exportUtils');

const app = express();
const PORT = process.env.PORT || 3001;

// Store scan results in memory (per session)
const scanStore = new Map();

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use('/api/', rateLimit({ windowMs: 60000, max: 100, message: { error: 'Rate limit exceeded' } }));

function normalizeUrl(url) {
  if (!url) throw new Error('URL দিন');
  const u = url.trim();
  return u.startsWith('http') ? u : `https://${u}`;
}

// Build options from request body
function buildOptions(body) {
  const opts = {};
  if (body.headers) opts.headers = body.headers;
  if (body.cookies) opts.cookies = body.cookies;
  if (body.useProxy) opts.useProxy = true;
  if (body.useDelay !== undefined) opts.useDelay = body.useDelay;
  return opts;
}

// ── Full Scan ──────────────────────────────────────────────────────────────
app.post('/api/scan', async (req, res) => {
  try {
    const url = normalizeUrl(req.body.url);
    const opts = buildOptions(req.body);
    const results = {}, errors = {};

    const tasks = [
      ['html',        () => htmlScraper.scrape(url, opts)],
      ['meta',        () => metaScraper.scrape(url, opts)],
      ['dns',         () => dnsScraper.lookup(url)],
      ['security',    () => securityScraper.analyze(url, opts)],
      ['analytics',   () => analyticsScraper.find(url, opts)],
      ['robots',      () => robotsScraper.fetch(url)],
      ['js',          () => jsScraper.analyze(url, opts)],
      ['cookies',     () => cookieScraper.extract(url, opts)],
      ['api',         () => apiScraper.discover(url, opts)],
      ['tech',        () => techFingerprint.detect(url, opts)],
    ];

    await Promise.allSettled(tasks.map(async ([k, fn]) => {
      try { results[k] = await fn(); }
      catch (e) { errors[k] = e.message; }
    }));

    const scanData = { url, results, errors, timestamp: new Date().toISOString() };

    // Store for export
    const scanId = Date.now().toString();
    scanStore.set(scanId, scanData);
    if (scanStore.size > 20) {
      const oldest = scanStore.keys().next().value;
      scanStore.delete(oldest);
    }

    res.json({ ...scanData, scanId });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Individual Scrapers ────────────────────────────────────────────────────
const individualScrapers = {
  html:       (url, opts) => htmlScraper.scrape(url, opts),
  meta:       (url, opts) => metaScraper.scrape(url, opts),
  dns:        (url)       => dnsScraper.lookup(url),
  security:   (url, opts) => securityScraper.analyze(url, opts),
  analytics:  (url, opts) => analyticsScraper.find(url, opts),
  robots:     (url)       => robotsScraper.fetch(url),
  js:         (url, opts) => jsScraper.analyze(url, opts),
  cookies:    (url, opts) => cookieScraper.extract(url, opts),
  api:        (url, opts) => apiScraper.discover(url, opts),
  tech:       (url, opts) => techFingerprint.detect(url, opts),
  subdomains: (url)       => subdomainFinder.find(url),
  directories:(url, opts) => dirBruteforce.bruteforce(url, opts),
};

Object.entries(individualScrapers).forEach(([key, fn]) => {
  app.post(`/api/${key}`, async (req, res) => {
    try {
      const url = normalizeUrl(req.body.url);
      const opts = buildOptions(req.body);
      const data = await fn(url, opts);
      res.json(data);
    } catch (e) { res.status(500).json({ error: e.message }); }
  });
});

// ── Export Endpoints ───────────────────────────────────────────────────────
app.post('/api/export/json', async (req, res) => {
  try {
    const { scanData } = req.body;
    if (!scanData) return res.status(400).json({ error: 'No scan data' });
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="scan-${Date.now()}.json"`);
    res.send(exportJSON(scanData));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/export/csv', async (req, res) => {
  try {
    const { scanData } = req.body;
    if (!scanData) return res.status(400).json({ error: 'No scan data' });
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="scan-${Date.now()}.csv"`);
    res.send('\uFEFF' + exportCSV(scanData)); // BOM for Excel
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/export/markdown', async (req, res) => {
  try {
    const { scanData } = req.body;
    if (!scanData) return res.status(400).json({ error: 'No scan data' });
    res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="scan-${Date.now()}.md"`);
    res.send(exportMarkdown(scanData));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/export/html', async (req, res) => {
  try {
    const { scanData } = req.body;
    if (!scanData) return res.status(400).json({ error: 'No scan data' });
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="scan-${Date.now()}.html"`);
    res.send(exportHTML(scanData));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/export/txt', async (req, res) => {
  try {
    const { scanData } = req.body;
    if (!scanData) return res.status(400).json({ error: 'No scan data' });
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="scan-${Date.now()}.txt"`);
    res.send(exportTXT(scanData));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/export/pdf', async (req, res) => {
  try {
    const { scanData } = req.body;
    if (!scanData) return res.status(400).json({ error: 'No scan data' });
    exportPDF(scanData, res);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Proxy List ─────────────────────────────────────────────────────────────
app.get('/api/proxies', async (req, res) => {
  try {
    const proxies = await getProxyList();
    res.json({ count: proxies.length, proxies: proxies.slice(0, 20) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Serve React ────────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, '../frontend/dist')));
app.get('*', (_, res) => res.sendFile(path.join(__dirname, '../frontend/dist/index.html')));

app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n╔══════════════════════════════════════╗`);
  console.log(`║  🕷️  Web Scraping Pro v3             ║`);
  console.log(`║  URL: http://localhost:${PORT}          ║`);
  console.log(`╚══════════════════════════════════════╝\n`);
});
