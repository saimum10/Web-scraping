import { useState, useCallback } from 'react';

// ── Constants ─────────────────────────────────────────────────────────────
const TABS = [
  { id:'html',      icon:'🌐', label:'HTML',        desc:'লিংক, ইমেজ, ফর্ম, ইমেইল' },
  { id:'meta',      icon:'📋', label:'Meta/SEO',    desc:'SEO, OG, Schema.org' },
  { id:'js',        icon:'⚙️', label:'JS Audit',    desc:'API Keys, Tokens, Streams' },
  { id:'api',       icon:'🔌', label:'API Finder',  desc:'Endpoints, GraphQL, WebSocket' },
  { id:'cookies',   icon:'🍪', label:'Cookies',     desc:'Session, Auth, CSRF, JWT' },
  { id:'tech',      icon:'🔧', label:'Technology',  desc:'Framework, CMS, Libraries' },
  { id:'security',  icon:'🛡️', label:'Security',    desc:'Headers, Score, HTTPS' },
  { id:'dns',       icon:'🔍', label:'DNS/WHOIS',   desc:'IP, NS, MX, WHOIS' },
  { id:'analytics', icon:'📊', label:'Trackers',    desc:'GA, GTM, Pixel IDs' },
  { id:'subdomains',icon:'🌐', label:'Subdomains',  desc:'DNS + CT Log Discovery' },
  { id:'directories',icon:'📂',label:'Directories', desc:'Bruteforce Hidden Paths' },
  { id:'robots',    icon:'🤖', label:'Robots',      desc:'robots.txt, Sitemap' },
];

const EXPORTS = [
  { id:'pdf',      icon:'📄', label:'PDF',      desc:'পেশাদার রিপোর্ট' },
  { id:'json',     icon:'{ }', label:'JSON',     desc:'Raw ডেটা, API-তে ব্যবহার' },
  { id:'csv',      icon:'📊', label:'CSV',      desc:'Excel-এ খুলুন' },
  { id:'html',     icon:'🌐', label:'HTML',     desc:'Browser রিপোর্ট' },
  { id:'markdown', icon:'📝', label:'Markdown', desc:'GitHub, Notion-এ ব্যবহার' },
  { id:'txt',      icon:'📃', label:'TXT',      desc:'Plain text রিপোর্ট' },
];

// ── Shared UI Components ───────────────────────────────────────────────────
function Badge({ color='blue', children, small }) {
  const c={blue:'#00d4ff',green:'#00d084',red:'#ff4757',yellow:'#ffd700',purple:'#c77dff',orange:'#ff9f43',gray:'#666',cyan:'#00e5ff'};
  const col=c[color]||c.blue;
  return <span style={{background:`${col}22`,border:`1px solid ${col}55`,color:col,padding:small?'1px 6px':'2px 9px',borderRadius:20,fontSize:small?9:10,fontWeight:700,letterSpacing:0.5,whiteSpace:'nowrap',display:'inline-block'}}>{children}</span>;
}

function CopyBtn({ text }) {
  const [ok,setOk]=useState(false);
  return <button onClick={()=>{navigator.clipboard.writeText(String(text));setOk(true);setTimeout(()=>setOk(false),1500);}} style={{background:ok?'#00d08422':'#ffffff11',border:`1px solid ${ok?'#00d084':'#ffffff22'}`,color:ok?'#00d084':'#888',padding:'2px 9px',borderRadius:6,cursor:'pointer',fontSize:10,flexShrink:0,transition:'all 0.2s'}}>{ok?'✓':'Copy'}</button>;
}

function Card({ title, children, badge, color='#00d4ff', warn }) {
  return <div style={{background:warn?'#ff475708':'#0d0d1a',border:`1px solid ${warn?'#ff475733':'#ffffff0d'}`,borderRadius:12,marginBottom:10,overflow:'hidden'}}>
    <div style={{padding:'9px 14px',borderBottom:'1px solid #ffffff08',display:'flex',justifyContent:'space-between',alignItems:'center',gap:8}}>
      <span style={{color:warn?'#ff6b7a':color,fontSize:11,fontWeight:700,letterSpacing:1.5,fontFamily:'Rajdhani'}}>{title}</span>
      {badge}
    </div>
    <div style={{padding:'10px 14px'}}>{children}</div>
  </div>;
}

function Row({ label, value, mono, warn }) {
  if (value===null||value===undefined||value==='') return null;
  return <div style={{display:'flex',gap:8,padding:'5px 0',borderBottom:'1px solid #ffffff05',flexWrap:'wrap'}}>
    <span style={{color:'#ffffff44',fontSize:11,minWidth:130,flexShrink:0}}>{label}</span>
    <span style={{color:warn?'#ff6b7a':'#e0e0ff',fontSize:11,fontFamily:mono?'JetBrains Mono,monospace':'inherit',wordBreak:'break-all',flex:1}}>{String(value)}</span>
  </div>;
}

function MonoBox({ value, color='#aaa', copy=true }) {
  return <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',background:'#ffffff06',borderRadius:6,padding:'5px 10px',marginBottom:3,gap:8}}>
    <span style={{color,fontSize:11,fontFamily:'JetBrains Mono,monospace',wordBreak:'break-all',flex:1}}>{value}</span>
    {copy&&<CopyBtn text={value}/>}
  </div>;
}

function Scroll({ children, h=220 }) {
  return <div style={{maxHeight:h,overflowY:'auto'}}>{children}</div>;
}

function Empty({ msg='স্ক্যান করলে ডেটা দেখাবে' }) {
  return <div style={{textAlign:'center',padding:'30px 0',color:'#333',fontSize:12}}>{msg}</div>;
}

// ── Tab: HTML ─────────────────────────────────────────────────────────────
function HtmlTab({ data }) {
  if (!data) return <Empty/>;
  return <>
    <Card title="📊 সারসংক্ষেপ">
      <div style={{display:'flex',gap:10,flexWrap:'wrap'}}>
        {Object.entries(data.counts||{}).map(([k,v])=>(
          <div key={k} style={{background:'#ffffff08',borderRadius:8,padding:'8px 14px',textAlign:'center',minWidth:55}}>
            <div style={{color:'#00d4ff',fontSize:18,fontWeight:700}}>{v}</div>
            <div style={{color:'#888',fontSize:10}}>{k}</div>
          </div>
        ))}
      </div>
    </Card>
    {data.emails?.length>0&&<Card title="📧 Email ঠিকানা" badge={<Badge>{data.emails.length}</Badge>}>
      {data.emails.map((e,i)=><MonoBox key={i} value={e} color="#ffd700"/>)}
    </Card>}
    {data.phones?.length>0&&<Card title="📞 ফোন নম্বর" badge={<Badge color="green">{data.phones.length}</Badge>}>
      {data.phones.map((p,i)=><MonoBox key={i} value={p} color="#00d084"/>)}
    </Card>}
    <Card title="🔗 লিংক" badge={<Badge>{data.links?.length}</Badge>}>
      <Scroll>{data.links?.slice(0,40).map((l,i)=>(
        <div key={i} style={{padding:'4px 0',borderBottom:'1px solid #ffffff04'}}>
          <div style={{color:'#00d4ff',fontSize:11,fontFamily:'monospace',wordBreak:'break-all'}}>{l.href}</div>
          {l.text&&<div style={{color:'#555',fontSize:10}}>{l.text}</div>}
        </div>
      ))}</Scroll>
    </Card>
    <Card title="🖼️ Image URLs" badge={<Badge color="purple">{data.images?.length}</Badge>}>
      <Scroll>{data.images?.slice(0,20).map((img,i)=>(
        <div key={i} style={{padding:'3px 0',borderBottom:'1px solid #ffffff04'}}>
          <div style={{color:'#c77dff',fontSize:11,fontFamily:'monospace',wordBreak:'break-all'}}>{img.src}</div>
          {img.alt&&<div style={{color:'#555',fontSize:10}}>{img.alt}</div>}
        </div>
      ))}</Scroll>
    </Card>
    {data.tables?.length>0&&<Card title="📊 Table Data">
      {data.tables.slice(0,3).map((table,ti)=>(
        <div key={ti} style={{overflowX:'auto',marginBottom:10}}>
          <table style={{borderCollapse:'collapse',width:'100%',fontSize:11}}>
            {table.map((row,ri)=>(
              <tr key={ri} style={{borderBottom:'1px solid #ffffff08'}}>
                {row.map((cell,ci)=><td key={ci} style={{padding:'4px 8px',color:ri===0?'#00d4ff':'#ccc',fontWeight:ri===0?700:400}}>{cell}</td>)}
              </tr>
            ))}
          </table>
        </div>
      ))}
    </Card>}
    {data.forms?.length>0&&<Card title="📝 Forms">
      {data.forms.map((f,i)=>(
        <div key={i} style={{background:'#ffffff05',borderRadius:8,padding:10,marginBottom:8}}>
          <div style={{display:'flex',gap:8,marginBottom:6,flexWrap:'wrap'}}>
            <Badge color={f.method==='POST'?'blue':'green'}>{f.method}</Badge>
            <span style={{color:'#aaa',fontSize:11,fontFamily:'monospace'}}>{f.action||'/'}</span>
          </div>
          <div>{f.inputs.map((inp,j)=><span key={j} style={{display:'inline-block',background:'#ffffff08',borderRadius:4,padding:'2px 7px',margin:'2px',fontSize:10,color:'#888'}}>{inp.name||inp.type}[{inp.type}]</span>)}</div>
        </div>
      ))}
    </Card>}
  </>;
}

// ── Tab: Meta ─────────────────────────────────────────────────────────────
function MetaTab({ data }) {
  if (!data) return <Empty/>;
  return <>
    <Card title="🔍 SEO">{Object.entries(data.seo||{}).map(([k,v])=><Row key={k} label={k} value={v}/>)}</Card>
    {Object.keys(data.og||{}).length>0&&<Card title="📘 Open Graph (Facebook)">{Object.entries(data.og).map(([k,v])=><Row key={k} label={`og:${k}`} value={v}/>)}</Card>}
    {Object.keys(data.twitter||{}).length>0&&<Card title="🐦 Twitter Card">{Object.entries(data.twitter).map(([k,v])=><Row key={k} label={`twitter:${k}`} value={v}/>)}</Card>}
    {data.schemas?.length>0&&<Card title="📐 Schema.org JSON-LD">
      {data.schemas.map((s,i)=>(
        <div key={i} style={{background:'#ffffff05',borderRadius:8,padding:10,marginBottom:8}}>
          <div style={{color:'#00d4ff',fontSize:11,marginBottom:4}}>@type: {s['@type']||'Unknown'}</div>
          <pre style={{color:'#aaa',fontSize:10,whiteSpace:'pre-wrap',wordBreak:'break-all',maxHeight:180,overflowY:'auto',margin:0}}>{JSON.stringify(s,null,2)}</pre>
        </div>
      ))}
    </Card>}
  </>;
}

// ── Tab: JS Audit ─────────────────────────────────────────────────────────
function JsTab({ data }) {
  if (!data) return <Empty/>;
  const [openIdx,setOpenIdx]=useState(null);
  const sevColor={critical:'red',high:'orange',medium:'yellow',info:'blue',low:'gray'};
  return <>
    <Card title="📦 সারসংক্ষেপ">
      <div style={{display:'flex',gap:10,flexWrap:'wrap',marginBottom:8}}>
        {[['JS Files',data.totalFiles,'#00d4ff'],['Analyzed',data.analyzedFiles,'#00d084'],['Inline',data.inlineScripts,'#ffd700'],['⚠️ Critical',data.criticalFindings,'#ff4757']].map(([l,v,c])=>(
          <div key={l} style={{background:`${c}11`,border:`1px solid ${c}33`,borderRadius:8,padding:'8px 14px',textAlign:'center',minWidth:55}}>
            <div style={{color:c,fontSize:18,fontWeight:700}}>{v||0}</div>
            <div style={{color:'#888',fontSize:10}}>{l}</div>
          </div>
        ))}
      </div>
    </Card>

    {/* Streaming APIs - প্রথমে দেখাও */}
    {data.streamingApis?.length>0&&<Card title="📺 Streaming APIs (Live/Video)" badge={<Badge color="yellow">{data.streamingApis.length}</Badge>} warn={false}>
      {data.streamingApis.map((s,i)=>(
        <div key={i} style={{display:'flex',gap:8,alignItems:'flex-start',padding:'5px 0',borderBottom:'1px solid #ffffff06'}}>
          <Badge color="yellow" small>{s.type}</Badge>
          <div style={{flex:1}}>
            <div style={{color:'#ffd700',fontSize:11,fontFamily:'monospace',wordBreak:'break-all'}}>{s.url}</div>
            {s.source&&<div style={{color:'#555',fontSize:9}}>from: {s.source.split('/').slice(-1)[0]}</div>}
          </div>
          <CopyBtn text={s.url}/>
        </div>
      ))}
    </Card>}

    {/* Sensitive findings */}
    {Object.keys(data.summary||{}).length>0&&<Card title="🔑 পাওয়া Keys & Credentials" warn>
      {Object.entries(data.summary).map(([label,info])=>(
        <div key={label} style={{marginBottom:12}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:4}}>
            <span style={{color:'#ff6b7a',fontSize:11,fontWeight:700}}>🔑 {label}</span>
            <div style={{display:'flex',gap:4}}>
              <Badge color={sevColor[info.severity]||'gray'} small>{info.severity||'info'}</Badge>
              <Badge color="red" small>{info.count}x</Badge>
            </div>
          </div>
          {info.matches.slice(0,5).map((m,i)=><MonoBox key={i} value={m} color="#ffaaaa"/>)}
        </div>
      ))}
    </Card>}

    {/* JS Files list */}
    <Card title="📂 JS Files">
      {data.jsUrls?.map((url,i)=>{
        const fr=data.fileResults?.find(f=>f.url===url);
        const hasF=fr?.findings?.length>0;
        return <div key={i} style={{marginBottom:4}}>
          <div onClick={()=>setOpenIdx(openIdx===i?null:i)} style={{display:'flex',justifyContent:'space-between',alignItems:'center',background:hasF?'#ff475710':'#ffffff05',borderRadius:8,padding:'6px 10px',cursor:'pointer',border:`1px solid ${hasF?'#ff475733':'transparent'}`}}>
            <span style={{color:hasF?'#ff6b7a':'#aaa',fontSize:10,fontFamily:'monospace',flex:1,wordBreak:'break-all'}}>{url.split('/').slice(-1)[0]||url.slice(-40)}</span>
            <div style={{display:'flex',gap:5,alignItems:'center',flexShrink:0,marginLeft:6}}>
              {fr?.sizeKB&&<span style={{color:'#555',fontSize:9}}>{fr.sizeKB}</span>}
              {hasF&&<Badge color="red" small>{fr.findings.length}</Badge>}
              {fr?.hasSourceMap&&<Badge color="yellow" small>SourceMap</Badge>}
              {fr?.error&&<Badge color="gray" small>Error</Badge>}
            </div>
          </div>
          {openIdx===i&&hasF&&<div style={{background:'#ff475708',border:'1px solid #ff475722',borderRadius:8,padding:10,marginTop:3}}>
            {fr.findings.map((f,fi)=>(
              <div key={fi} style={{marginBottom:8}}>
                <div style={{color:'#ff9f43',fontSize:11,fontWeight:700,marginBottom:3}}>{f.label}</div>
                {f.matches.slice(0,3).map((m,mi)=><MonoBox key={mi} value={m} color="#ffccaa"/>)}
              </div>
            ))}
          </div>}
        </div>;
      })}
    </Card>
  </>;
}

// ── Tab: API Finder ───────────────────────────────────────────────────────
function ApiTab({ data }) {
  if (!data) return <Empty/>;
  const [section,setSection]=useState('api');
  const methodColor={GET:'green',POST:'blue',PUT:'yellow',DELETE:'red',PATCH:'purple'};
  return <>
    <Card title="🔌 API Discovery সারসংক্ষেপ">
      <div style={{display:'flex',gap:10,flexWrap:'wrap'}}>
        {[['Endpoints',data.totalEndpoints,'#00d4ff'],['Streaming',data.streamingApis?.length,'#ffd700'],['GraphQL',data.graphqlQueries?.length,'#c77dff'],['WebSocket',data.websockets?.length,'#00d084'],['Probed',data.probeResults?.length,'#888']].map(([l,v,c])=>(
          <div key={l} style={{background:'#ffffff08',borderRadius:8,padding:'7px 12px',textAlign:'center',minWidth:55}}>
            <div style={{color:c,fontSize:16,fontWeight:700}}>{v||0}</div>
            <div style={{color:'#888',fontSize:10}}>{l}</div>
          </div>
        ))}
      </div>
    </Card>

    {/* Streaming APIs */}
    {data.streamingApis?.length>0&&<Card title="📺 Streaming APIs" badge={<Badge color="yellow">{data.streamingApis.length}</Badge>}>
      {data.streamingApis.map((s,i)=>(
        <div key={i} style={{display:'flex',gap:8,alignItems:'center',padding:'4px 0',borderBottom:'1px solid #ffffff05'}}>
          <Badge color="yellow" small>{s.type}</Badge>
          <span style={{color:'#ffd700',fontSize:11,fontFamily:'monospace',flex:1,wordBreak:'break-all'}}>{s.url}</span>
          <CopyBtn text={s.url}/>
        </div>
      ))}
    </Card>}

    {/* XHR Patterns */}
    {data.xhrPatterns?.length>0&&<Card title="📡 XHR/Fetch Calls" badge={<Badge>{data.xhrPatterns.length}</Badge>}>
      <Scroll h={200}>{data.xhrPatterns.map((x,i)=>(
        <div key={i} style={{display:'flex',gap:8,alignItems:'center',padding:'4px 0',borderBottom:'1px solid #ffffff04'}}>
          <Badge color={methodColor[x.method]||'gray'} small>{x.method}</Badge>
          <span style={{color:'#e0e0ff',fontSize:11,fontFamily:'monospace',flex:1,wordBreak:'break-all'}}>{x.endpoint}</span>
          <CopyBtn text={x.endpoint}/>
        </div>
      ))}</Scroll>
    </Card>}

    {/* Probe Results */}
    {data.probeResults?.length>0&&<Card title="🔎 Path Probe Results" badge={<Badge color="yellow">{data.probeResults.filter(p=>p.interesting).length} interesting</Badge>}>
      {data.probeResults.map((r,i)=>(
        <div key={i} style={{display:'flex',gap:8,alignItems:'center',padding:'5px 0',borderBottom:'1px solid #ffffff04'}}>
          <Badge color={r.status===200?'green':r.status===401||r.status===403?'yellow':'gray'} small>{r.status}</Badge>
          <span style={{color:r.interesting?'#ffd700':'#666',fontSize:11,fontFamily:'monospace',flex:1}}>{r.path}</span>
          {r.isJson&&<Badge color="blue" small>JSON</Badge>}
          <span style={{color:'#444',fontSize:9}}>{r.contentType?.split('/')[1]}</span>
        </div>
      ))}
    </Card>}

    {/* Categorized */}
    <Card title="📂 Endpoint Categories">
      <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:10}}>
        {Object.entries(data.categorized||{}).filter(([,eps])=>eps.length>0).map(([cat,eps])=>(
          <button key={cat} onClick={()=>setSection(cat)} style={{background:section===cat?'#00d4ff22':'#ffffff08',border:`1px solid ${section===cat?'#00d4ff':'#ffffff11'}`,color:section===cat?'#00d4ff':'#888',borderRadius:20,padding:'4px 12px',cursor:'pointer',fontSize:11}}>{cat} ({eps.length})</button>
        ))}
      </div>
      <Scroll h={180}>{(data.categorized?.[section]||[]).map((ep,i)=><MonoBox key={i} value={ep}/>)}</Scroll>
    </Card>

    {/* WebSocket */}
    {data.websockets?.length>0&&<Card title="🔄 WebSocket Connections" color="#ffd700">
      {data.websockets.map((ws,i)=><MonoBox key={i} value={ws} color="#ffd700"/>)}
    </Card>}

    {/* GraphQL */}
    {data.graphqlQueries?.length>0&&<Card title="⚡ GraphQL Queries" color="#c77dff">
      {data.graphqlQueries.slice(0,5).map((q,i)=>(
        <pre key={i} style={{color:'#c77dff',fontSize:10,background:'#c77dff0a',borderRadius:6,padding:8,overflowX:'auto',margin:'0 0 8px',whiteSpace:'pre-wrap'}}>{q}</pre>
      ))}
    </Card>}
  </>;
}

// ── Tab: Cookies ──────────────────────────────────────────────────────────
function CookiesTab({ data }) {
  if (!data) return <Empty/>;
  const rC={safe:'green',warning:'yellow',danger:'red'};
  return <>
    <Card title="🍪 সারসংক্ষেপ">
      <div style={{display:'flex',gap:10,flexWrap:'wrap'}}>
        {[['মোট',data.totalCookies,'#00d4ff'],['Session/Auth',(data.summary?.session||0)+(data.summary?.auth||0),'#ffd700'],['Tracking',data.summary?.tracking,'#ff9f43'],['⚠️ Unsafe',data.summary?.dangerous,'#ff4757']].map(([l,v,c])=>(
          <div key={l} style={{background:'#ffffff08',borderRadius:8,padding:'7px 12px',textAlign:'center',minWidth:55}}>
            <div style={{color:c,fontSize:16,fontWeight:700}}>{v||0}</div>
            <div style={{color:'#888',fontSize:10}}>{l}</div>
          </div>
        ))}
      </div>
    </Card>
    {data.cookies?.map((c,i)=>(
      <Card key={i} title={`🍪 ${c.name}`} badge={<Badge color={rC[c.securityRating]||'gray'}>{c.type}</Badge>} warn={c.securityRating==='danger'}>
        <div style={{display:'flex',gap:5,flexWrap:'wrap',marginBottom:8}}>
          {c.httpOnly&&<Badge color="green" small>HttpOnly ✓</Badge>}
          {!c.httpOnly&&<Badge color="red" small>No HttpOnly</Badge>}
          {c.secure&&<Badge color="green" small>Secure ✓</Badge>}
          {!c.secure&&<Badge color="red" small>No Secure</Badge>}
          {c.sameSite&&<Badge color="blue" small>SameSite={c.sameSite}</Badge>}
          {!c.sameSite&&<Badge color="yellow" small>No SameSite</Badge>}
          {c.isJwt&&<Badge color="yellow" small>JWT 🔓</Badge>}
        </div>
        <Row label="Value (first 120)" value={c.value?.slice(0,120)} mono/>
        {c.decodedValue&&<Row label="Decoded" value={c.decodedValue} mono/>}
        {c.jwtPayload&&<div style={{marginTop:8}}>
          <div style={{color:'#ffd700',fontSize:11,marginBottom:4}}>JWT Payload:</div>
          <pre style={{color:'#aaa',fontSize:10,background:'#ffffff05',borderRadius:6,padding:8,overflowX:'auto',margin:0}}>{JSON.stringify(c.jwtPayload,null,2)}</pre>
        </div>}
        <Row label="Path" value={c.path}/>
        <Row label="Domain" value={c.domain}/>
        <Row label="Expires" value={c.expires}/>
      </Card>
    ))}
    {data.localStorageHints?.length>0&&<Card title="💾 LocalStorage / SessionStorage" color="#c77dff">
      {data.localStorageHints.map((h,i)=>(
        <div key={i} style={{display:'flex',gap:8,padding:'4px 0',borderBottom:'1px solid #ffffff05',alignItems:'center'}}>
          <Badge color={h.storage==='localStorage'?'purple':'blue'} small>{h.storage}</Badge>
          <Badge color={h.action==='setItem'?'orange':'green'} small>{h.action}</Badge>
          <span style={{color:'#e0e0ff',fontSize:11,fontFamily:'monospace'}}>{h.key}</span>
        </div>
      ))}
    </Card>}
    {data.corsHeaders&&Object.values(data.corsHeaders).some(Boolean)&&<Card title="🌍 CORS">
      <Row label="Allow-Origin" value={data.corsHeaders.origin} mono/>
      <Row label="Credentials" value={data.corsHeaders.credentials}/>
      <Row label="Methods" value={data.corsHeaders.methods}/>
      <Row label="Headers" value={data.corsHeaders.headers} mono/>
    </Card>}
  </>;
}

// ── Tab: Technology ───────────────────────────────────────────────────────
function TechTab({ data }) {
  if (!data) return <Empty/>;
  const catColors={'JS Framework':'blue','Backend':'green','CMS':'yellow','E-Commerce':'orange','Web Server':'gray','CDN':'cyan','Analytics':'purple','Security':'red','Payment':'green','Chat':'blue','Media':'yellow','CSS Framework':'purple','JS Library':'blue','Language':'orange','Fonts':'gray'};
  return <>
    <Card title="🔧 Technology সারসংক্ষেপ" badge={<Badge>{data.totalDetected} detected</Badge>}>
      <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:10}}>
        <Row label="Server" value={data.rawHeaders?.server}/>
        <Row label="X-Powered-By" value={data.rawHeaders?.poweredBy}/>
      </div>
      <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
        {Object.entries(data.categoryCounts||{}).map(([cat,count])=>(
          <div key={cat} style={{background:'#ffffff08',borderRadius:8,padding:'5px 10px',textAlign:'center'}}>
            <div style={{color:'#00d4ff',fontSize:14,fontWeight:700}}>{count}</div>
            <div style={{color:'#888',fontSize:9}}>{cat}</div>
          </div>
        ))}
      </div>
    </Card>
    {Object.entries(data.grouped||{}).map(([cat,items])=>(
      <Card key={cat} title={`${cat}`} color={`var(--c,#00d4ff)`}>
        <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
          {items.map((t,i)=>(
            <div key={i} style={{background:'#ffffff08',border:'1px solid #ffffff11',borderRadius:8,padding:'8px 12px'}}>
              <div style={{color:'#e0e0ff',fontSize:12,fontWeight:600}}>{t.name}</div>
              {t.version&&<div style={{color:'#888',fontSize:10}}>v{t.version}</div>}
              <Badge color={catColors[cat]||'blue'} small>{t.confidence}</Badge>
            </div>
          ))}
        </div>
      </Card>
    ))}
  </>;
}

// ── Tab: Security ─────────────────────────────────────────────────────────
function SecurityTab({ data }) {
  if (!data) return <Empty/>;
  const sc=data.securityScore||0;
  const scC=sc>=70?'#00d084':sc>=40?'#ffd700':'#ff4757';
  return <>
    <Card title="⚙️ সার্ভার তথ্য">
      <div style={{display:'flex',gap:10,flexWrap:'wrap',marginBottom:10}}>
        <div style={{background:`${scC}22`,border:`1px solid ${scC}44`,borderRadius:8,padding:'10px 16px',textAlign:'center'}}>
          <div style={{color:scC,fontSize:24,fontWeight:700}}>{sc}%</div>
          <div style={{color:'#888',fontSize:10}}>Security Score</div>
        </div>
        <div style={{background:'#ffffff08',borderRadius:8,padding:'10px 16px',textAlign:'center'}}>
          <div style={{color:'#00d4ff',fontSize:24,fontWeight:700}}>{data.statusCode}</div>
          <div style={{color:'#888',fontSize:10}}>Status</div>
        </div>
      </div>
      <Row label="Server" value={data.server} mono/>
      <Row label="X-Powered-By" value={data.poweredBy} mono/>
      <Row label="Framework" value={data.framework}/>
      <Row label="HTTPS" value={data.isHttps?'✅ হ্যাঁ':'❌ না'} warn={!data.isHttps}/>
      <Row label="Content-Type" value={data.contentType} mono/>
    </Card>
    <Card title="🔒 Security Headers">
      {data.securityHeaders?.map((h,i)=>(
        <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',padding:'7px 0',borderBottom:'1px solid #ffffff05',gap:8}}>
          <div style={{flex:1}}>
            <div style={{color:h.present?'#00d084':'#ff4757',fontSize:11,fontWeight:700}}>{h.present?'✓':'✗'} {h.name}</div>
            <div style={{color:'#555',fontSize:10}}>{h.desc}</div>
            {h.value&&<div style={{color:'#888',fontSize:10,fontFamily:'monospace',wordBreak:'break-all'}}>{h.value.slice(0,80)}</div>}
          </div>
          <Badge color={h.present?'green':'red'} small>{h.present?'আছে':'নেই'}</Badge>
        </div>
      ))}
    </Card>
    <Card title="📨 All Response Headers">
      <Scroll h={280}>{Object.entries(data.allHeaders||{}).map(([k,v])=><Row key={k} label={k} value={String(v)} mono/>)}</Scroll>
    </Card>
  </>;
}

// ── Tab: DNS ──────────────────────────────────────────────────────────────
function DnsTab({ data }) {
  if (!data) return <Empty/>;
  return <>
    <Card title="🌐 IP তথ্য">
      <Row label="Hostname" value={data.hostname} mono/>
      <Row label="IPv4" value={data.ipv4?.join(', ')} mono/>
      <Row label="IPv6" value={data.ipv6?.join(', ')} mono/>
      <Row label="CDN/Hosting" value={data.cdn}/>
      <Row label="Reverse DNS" value={data.reverseDns?.join(', ')} mono/>
    </Card>
    <Card title="📡 DNS Records">
      <Row label="Nameservers" value={data.nameservers?.join(', ')} mono/>
      <Row label="CNAME" value={data.cname?.join(', ')} mono/>
      <Row label="MX Records" value={data.mx?.map(m=>`${m.exchange}(${m.priority})`).join(', ')} mono/>
      {data.txt?.length>0&&<>
        <div style={{color:'#ffffff44',fontSize:11,marginTop:8,marginBottom:4}}>TXT Records:</div>
        {data.txt.map((t,i)=><div key={i} style={{color:'#aaa',fontSize:10,fontFamily:'monospace',padding:'2px 0',wordBreak:'break-all'}}>{t}</div>)}
      </>}
    </Card>
    {data.whois&&<Card title="📋 WHOIS">
      <Row label="Domain" value={data.whois.name}/>
      <Row label="Registrar" value={data.whois.registrar}/>
      <Row label="Registered" value={data.whois.registered}/>
      <Row label="Expires" value={data.whois.expires}/>
      <Row label="Status" value={data.whois.status?.join(', ')}/>
    </Card>}
  </>;
}

// ── Tab: Analytics ────────────────────────────────────────────────────────
function AnalyticsTab({ data }) {
  if (!data) return <Empty/>;
  const cols=['blue','green','yellow','purple','orange','red','cyan'];
  return <Card title="📊 পাওয়া Trackers & IDs" badge={<Badge>{data.found}</Badge>}>
    {data.found===0?<Empty msg="কোনো tracker পাওয়া যায়নি"/>:
      Object.entries(data.trackers||{}).map(([name,values],i)=>(
        <div key={name} style={{marginBottom:12}}>
          <div style={{color:['#00d4ff','#00d084','#ffd700','#c77dff','#ff9f43','#ff4757','#00e5ff'][i%7],fontSize:12,fontWeight:700,marginBottom:4}}>📍 {name}</div>
          {values.map((v,j)=><MonoBox key={j} value={v}/>)}
        </div>
      ))
    }
  </Card>;
}

// ── Tab: Subdomains ───────────────────────────────────────────────────────
function SubdomainsTab({ data }) {
  if (!data) return <Empty/>;
  return <>
    <Card title="🌐 Subdomain Discovery সারসংক্ষেপ">
      <div style={{display:'flex',gap:10,flexWrap:'wrap',marginBottom:8}}>
        {[['মোট পাওয়া',data.totalFound,'#00d4ff'],['CT Log',data.ctLogFindings,'#00d084'],['DNS Brute',data.bruteForceFindings,'#ffd700']].map(([l,v,c])=>(
          <div key={l} style={{background:'#ffffff08',borderRadius:8,padding:'7px 12px',textAlign:'center'}}>
            <div style={{color:c,fontSize:16,fontWeight:700}}>{v||0}</div>
            <div style={{color:'#888',fontSize:10}}>{l}</div>
          </div>
        ))}
      </div>
    </Card>
    <Card title="🔗 পাওয়া Subdomains">
      <Scroll h={400}>{data.found?.map((s,i)=>(
        <div key={i} style={{padding:'6px 0',borderBottom:'1px solid #ffffff05',display:'flex',gap:8,alignItems:'center',flexWrap:'wrap'}}>
          <span style={{color:s.active?'#00d4ff':'#888',fontSize:11,fontFamily:'monospace',flex:1,minWidth:150}}>{s.subdomain}</span>
          {s.ip&&<span style={{color:'#888',fontSize:10,fontFamily:'monospace'}}>{s.ip}</span>}
          {s.httpStatus&&<Badge color={s.httpStatus===200?'green':s.httpStatus===403?'yellow':'gray'} small>{s.httpStatus}</Badge>}
          <Badge color={s.type==='CT Log'?'green':'blue'} small>{s.type||'DNS'}</Badge>
          {s.active&&<Badge color="green" small>● Live</Badge>}
          {s.server&&<span style={{color:'#555',fontSize:9}}>{s.server}</span>}
        </div>
      ))}</Scroll>
    </Card>
  </>;
}

// ── Tab: Directories ──────────────────────────────────────────────────────
function DirectoriesTab({ data }) {
  if (!data) return <Empty/>;
  return <>
    <Card title="📂 Directory Scan সারসংক্ষেপ">
      <div style={{display:'flex',gap:10,flexWrap:'wrap',marginBottom:8}}>
        {[['স্ক্যান করা',data.totalScanned,'#888'],['পাওয়া',data.found?.length,'#00d4ff'],['⚠️ Critical',data.criticalFound,'#ff4757']].map(([l,v,c])=>(
          <div key={l} style={{background:'#ffffff08',borderRadius:8,padding:'7px 12px',textAlign:'center'}}>
            <div style={{color:c,fontSize:16,fontWeight:700}}>{v||0}</div>
            <div style={{color:'#888',fontSize:10}}>{l}</div>
          </div>
        ))}
      </div>
      <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
        {Object.entries(data.byStatus||{}).map(([s,c])=>c>0&&<Badge key={s} color={s==='200'?'green':s.includes('301')?'blue':s.includes('401')?'yellow':'red'}>{s}: {c}</Badge>)}
      </div>
    </Card>
    {data.found?.length>0&&<Card title="🚨 পাওয়া Paths" warn>
      <Scroll h={400}>{data.found.map((d,i)=>(
        <div key={i} style={{padding:'6px 0',borderBottom:'1px solid #ffffff05',display:'flex',gap:8,alignItems:'center'}}>
          <Badge color={d.status===200?'green':d.status===403?'yellow':d.status===401?'orange':'gray'} small>{d.status}</Badge>
          <span style={{color:d.critical?'#ff4757':d.status===200?'#00d4ff':'#888',fontSize:11,fontFamily:'monospace',flex:1}}>{d.path}</span>
          {d.critical&&<Badge color="red" small>⚠️ Critical</Badge>}
          {d.isJson&&<Badge color="blue" small>JSON</Badge>}
          <span style={{color:'#444',fontSize:9}}>{d.contentType?.replace('text/','')}</span>
          <CopyBtn text={`${data.baseUrl}${d.path}`}/>
        </div>
      ))}</Scroll>
    </Card>}
  </>;
}

// ── Tab: Robots ───────────────────────────────────────────────────────────
function RobotsTab({ data }) {
  if (!data) return <Empty/>;
  return <>
    {data.robots?.content&&<Card title="🤖 robots.txt">
      <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:10}}>
        <Badge color="red">Disallowed: {data.robots.disallowed.length}</Badge>
        <Badge color="green">Allowed: {data.robots.allowed.length}</Badge>
        {data.robots.crawlDelay&&<Badge color="yellow">Crawl-Delay: {data.robots.crawlDelay}</Badge>}
      </div>
      {data.robots.disallowed.slice(0,30).map((p,i)=><div key={i} style={{color:'#ff6b7a',fontSize:11,fontFamily:'monospace',padding:'2px 0'}}>{p}</div>)}
      <details style={{marginTop:8}}>
        <summary style={{color:'#888',fontSize:11,cursor:'pointer'}}>Raw দেখুন</summary>
        <pre style={{color:'#aaa',fontSize:10,whiteSpace:'pre-wrap',marginTop:6,maxHeight:200,overflowY:'auto'}}>{data.robots.content}</pre>
      </details>
    </Card>}
    {data.sitemap?.found&&<Card title={`🗺️ Sitemap`} badge={<Badge>{data.sitemap.count} URLs</Badge>}>
      <Scroll h={200}>{data.sitemap.urls.map((u,i)=><div key={i} style={{color:'#00d4ff',fontSize:11,fontFamily:'monospace',padding:'2px 0',wordBreak:'break-all'}}>{u}</div>)}</Scroll>
    </Card>}
    {data.securityTxt&&<Card title="🔐 security.txt">
      <pre style={{color:'#aaa',fontSize:10,whiteSpace:'pre-wrap'}}>{data.securityTxt}</pre>
    </Card>}
  </>;
}

// ── Export Panel ──────────────────────────────────────────────────────────
function ExportPanel({ scanData, onClose }) {
  const [loading, setLoading] = useState(null);

  const doExport = async (type) => {
    if (!scanData) return;
    setLoading(type);
    try {
      const r = await fetch(`/api/export/${type}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scanData }),
      });
      const blob = await r.blob();
      const ext = { pdf:'pdf', json:'json', csv:'csv', html:'html', markdown:'md', txt:'txt' }[type];
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `webscraping-report-${Date.now()}.${ext}`; a.click();
      URL.revokeObjectURL(url);
    } catch (e) { alert('Export failed: ' + e.message); }
    setLoading(null);
  };

  return <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.8)',zIndex:100,display:'flex',alignItems:'center',justifyContent:'center',padding:16}}>
    <div style={{background:'#0d0d1a',border:'1px solid #ffffff15',borderRadius:16,padding:20,width:'100%',maxWidth:380}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}>
        <h3 style={{margin:0,color:'#00d4ff',fontFamily:'Rajdhani',fontSize:16,letterSpacing:1}}>📥 Export Report</h3>
        <button onClick={onClose} style={{background:'none',border:'none',color:'#888',cursor:'pointer',fontSize:18}}>✕</button>
      </div>
      <div style={{display:'flex',flexDirection:'column',gap:8}}>
        {EXPORTS.map(ex=>(
          <button key={ex.id} onClick={()=>doExport(ex.id)} disabled={loading===ex.id} style={{display:'flex',alignItems:'center',gap:12,padding:'12px 16px',background:'#ffffff08',border:'1px solid #ffffff11',borderRadius:10,cursor:'pointer',transition:'all 0.2s',textAlign:'left'}}>
            <span style={{fontSize:20}}>{ex.icon}</span>
            <div style={{flex:1}}>
              <div style={{color:'#fff',fontSize:13,fontWeight:700,fontFamily:'Rajdhani'}}>{ex.label}</div>
              <div style={{color:'#666',fontSize:10}}>{ex.desc}</div>
            </div>
            {loading===ex.id&&<span style={{color:'#00d4ff',animation:'spin 1s linear infinite',display:'inline-block'}}>⟳</span>}
          </button>
        ))}
      </div>
    </div>
  </div>;
}

// ── Settings Panel ────────────────────────────────────────────────────────
function SettingsPanel({ settings, onChange, onClose }) {
  const [proxies, setProxies] = useState([]);
  const [loadingProxy, setLoadingProxy] = useState(false);

  const fetchProxies = async () => {
    setLoadingProxy(true);
    try {
      const r = await fetch('/api/proxies');
      const d = await r.json();
      setProxies(d.proxies || []);
    } catch (_) {}
    setLoadingProxy(false);
  };

  return <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.85)',zIndex:100,display:'flex',alignItems:'flex-start',justifyContent:'center',padding:16,overflowY:'auto'}}>
    <div style={{background:'#0d0d1a',border:'1px solid #ffffff15',borderRadius:16,padding:20,width:'100%',maxWidth:440,marginTop:20}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}>
        <h3 style={{margin:0,color:'#00d4ff',fontFamily:'Rajdhani',fontSize:16,letterSpacing:1}}>⚙️ Advanced Settings</h3>
        <button onClick={onClose} style={{background:'none',border:'none',color:'#888',cursor:'pointer',fontSize:18}}>✕</button>
      </div>

      {/* Custom Headers */}
      <div style={{marginBottom:14}}>
        <label style={{color:'#aaa',fontSize:11,letterSpacing:1,display:'block',marginBottom:6}}>🔑 Custom Headers (JSON format)</label>
        <textarea value={settings.headersRaw||''} onChange={e=>onChange({...settings,headersRaw:e.target.value})} placeholder='{"Authorization":"Bearer token","X-API-Key":"your-key"}' style={{width:'100%',background:'#060610',border:'1px solid #ffffff15',borderRadius:8,padding:'8px 10px',color:'#fff',fontSize:11,fontFamily:'monospace',resize:'vertical',minHeight:70}}/>
        <div style={{color:'#555',fontSize:10,marginTop:3}}>JSON অবজেক্ট হিসেবে header দিন</div>
      </div>

      {/* Custom Cookies */}
      <div style={{marginBottom:14}}>
        <label style={{color:'#aaa',fontSize:11,letterSpacing:1,display:'block',marginBottom:6}}>🍪 Session Cookie</label>
        <textarea value={settings.cookies||''} onChange={e=>onChange({...settings,cookies:e.target.value})} placeholder="PHPSESSID=abc123; auth_token=eyJ..." style={{width:'100%',background:'#060610',border:'1px solid #ffffff15',borderRadius:8,padding:'8px 10px',color:'#fff',fontSize:11,fontFamily:'monospace',resize:'vertical',minHeight:50}}/>
        <div style={{color:'#555',fontSize:10,marginTop:3}}>Browser থেকে Cookie কপি করে পেস্ট করুন</div>
      </div>

      {/* Proxy Toggle */}
      <div style={{marginBottom:14,display:'flex',justifyContent:'space-between',alignItems:'center',background:'#ffffff05',borderRadius:8,padding:'10px 14px'}}>
        <div>
          <div style={{color:'#fff',fontSize:12}}>🌐 Free Proxy Rotation</div>
          <div style={{color:'#555',fontSize:10}}>IP block এড়াতে free proxy ব্যবহার</div>
        </div>
        <div onClick={()=>onChange({...settings,useProxy:!settings.useProxy})} style={{width:44,height:24,borderRadius:12,background:settings.useProxy?'#00d4ff':'#333',cursor:'pointer',position:'relative',transition:'all 0.3s'}}>
          <div style={{position:'absolute',top:2,left:settings.useProxy?20:2,width:20,height:20,borderRadius:'50%',background:'#fff',transition:'all 0.3s'}}/>
        </div>
      </div>

      {/* Smart Delay */}
      <div style={{marginBottom:14,display:'flex',justifyContent:'space-between',alignItems:'center',background:'#ffffff05',borderRadius:8,padding:'10px 14px'}}>
        <div>
          <div style={{color:'#fff',fontSize:12}}>⏱️ Smart Delay (Auto)</div>
          <div style={{color:'#555',fontSize:10}}>Rate limit এড়াতে random delay</div>
        </div>
        <div onClick={()=>onChange({...settings,useDelay:!settings.useDelay})} style={{width:44,height:24,borderRadius:12,background:settings.useDelay!==false?'#00d4ff':'#333',cursor:'pointer',position:'relative',transition:'all 0.3s'}}>
          <div style={{position:'absolute',top:2,left:settings.useDelay!==false?20:2,width:20,height:20,borderRadius:'50%',background:'#fff',transition:'all 0.3s'}}/>
        </div>
      </div>

      {/* Proxy list */}
      {settings.useProxy&&<div style={{marginBottom:14}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:6}}>
          <label style={{color:'#aaa',fontSize:11}}>Available Free Proxies</label>
          <button onClick={fetchProxies} disabled={loadingProxy} style={{background:'#00d4ff22',border:'1px solid #00d4ff44',color:'#00d4ff',padding:'3px 10px',borderRadius:6,cursor:'pointer',fontSize:10}}>
            {loadingProxy?'Loading...':'Fetch Proxies'}
          </button>
        </div>
        {proxies.length>0&&<div style={{background:'#060610',borderRadius:8,padding:8,maxHeight:100,overflowY:'auto'}}>
          {proxies.slice(0,10).map((p,i)=><div key={i} style={{color:'#aaa',fontSize:10,fontFamily:'monospace',padding:'1px 0'}}>{p}</div>)}
        </div>}
      </div>}

      <button onClick={onClose} style={{width:'100%',padding:11,background:'linear-gradient(135deg,#00d4ff,#0070f3)',border:'none',borderRadius:10,color:'#fff',fontWeight:700,cursor:'pointer',fontFamily:'Rajdhani',letterSpacing:1}}>✓ সংরক্ষণ করুন</button>
    </div>
  </div>;
}

// ── Main App ──────────────────────────────────────────────────────────────
export default function App() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [errors, setErrors] = useState({});
  const [activeTab, setActiveTab] = useState('html');
  const [tabLoading, setTabLoading] = useState(null);
  const [scanData, setScanData] = useState(null);
  const [showExport, setShowExport] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [settings, setSettings] = useState({ useDelay: true, useProxy: false, cookies: '', headersRaw: '' });
  const [scanTime, setScanTime] = useState(null);

  const buildOpts = () => {
    const opts = { useDelay: settings.useDelay !== false, useProxy: !!settings.useProxy };
    if (settings.cookies?.trim()) opts.cookies = settings.cookies.trim();
    if (settings.headersRaw?.trim()) {
      try { opts.headers = JSON.parse(settings.headersRaw); } catch (_) {}
    }
    return opts;
  };

  const scan = async () => {
    if (!url.trim()) return;
    setLoading(true); setResults(null); setErrors({}); setScanData(null); setScanTime(null);
    const t0 = Date.now();
    try {
      const r = await fetch('/api/scan', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ url: url.trim(), ...buildOpts() }) });
      const data = await r.json();
      if (data.error) { setErrors({ global: data.error }); }
      else { setResults(data.results); setErrors(data.errors||{}); setScanData(data); setScanTime(((Date.now()-t0)/1000).toFixed(1)); }
    } catch (e) { setErrors({ global: e.message }); }
    setLoading(false);
  };

  const scanTab = useCallback(async (tabId) => {
    if (!url.trim()) return;
    setTabLoading(tabId);
    try {
      const r = await fetch(`/api/${tabId}`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ url: url.trim(), ...buildOpts() }) });
      const data = await r.json();
      if (data.error) setErrors(p=>({...p,[tabId]:data.error}));
      else {
        setResults(p=>({...(p||{}),[tabId]:data}));
        setScanData(p=>p?{...p,results:{...(p.results||{}),[tabId]:data}}:null);
      }
    } catch (e) { setErrors(p=>({...p,[tabId]:e.message})); }
    setTabLoading(null);
  }, [url, settings]);

  const tabComponents = {
    html: <HtmlTab data={results?.html}/>,
    meta: <MetaTab data={results?.meta}/>,
    js: <JsTab data={results?.js}/>,
    api: <ApiTab data={results?.api}/>,
    cookies: <CookiesTab data={results?.cookies}/>,
    tech: <TechTab data={results?.tech}/>,
    security: <SecurityTab data={results?.security}/>,
    dns: <DnsTab data={results?.dns}/>,
    analytics: <AnalyticsTab data={results?.analytics}/>,
    subdomains: <SubdomainsTab data={results?.subdomains}/>,
    directories: <DirectoriesTab data={results?.directories}/>,
    robots: <RobotsTab data={results?.robots}/>,
  };

  return (
    <div style={{minHeight:'100vh',background:'#060610',color:'#fff',fontFamily:"'Noto Sans Bengali','Segoe UI',sans-serif"}}>
      <style>{`
        *{box-sizing:border-box}
        ::-webkit-scrollbar{width:3px;height:3px}
        ::-webkit-scrollbar-thumb{background:#ffffff22;border-radius:3px}
        input,textarea{outline:none}
        input:focus,textarea:focus{border-color:#00d4ff88!important}
        details summary::-webkit-details-marker{display:none}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes fadein{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:none}}
        .fade{animation:fadein .3s ease}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
        button:hover{opacity:0.88}
      `}</style>

      {/* Header */}
      <div style={{background:'linear-gradient(90deg,#08081a,#100830)',borderBottom:'1px solid #ffffff0d',padding:'10px 14px',display:'flex',justifyContent:'space-between',alignItems:'center',position:'sticky',top:0,zIndex:50}}>
        <div style={{display:'flex',alignItems:'center',gap:10}}>
          <div style={{width:32,height:32,borderRadius:8,overflow:'hidden',flexShrink:0}}>
            <img src="/icon.png" alt="icon" style={{width:'100%',height:'100%',objectFit:'cover'}} onError={e=>{e.target.style.display='none';}}/>
          </div>
          <div>
            <h1 style={{margin:0,fontFamily:'Rajdhani,sans-serif',fontSize:18,fontWeight:700,background:'linear-gradient(90deg,#00d4ff,#c77dff)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent',letterSpacing:1}}>Web Scraping</h1>
            <p style={{margin:0,color:'#ffffff33',fontSize:8,letterSpacing:2}}>OSINT & SECURITY AUDIT v3</p>
          </div>
        </div>
        <div style={{display:'flex',gap:8,alignItems:'center'}}>
          {scanTime&&<span style={{color:'#00d084',fontSize:10}}>✅ {scanTime}s</span>}
          {scanData&&<button onClick={()=>setShowExport(true)} style={{background:'#00d4ff22',border:'1px solid #00d4ff44',color:'#00d4ff',padding:'6px 12px',borderRadius:8,cursor:'pointer',fontSize:11,fontFamily:'Rajdhani',fontWeight:700}}>📥 Export</button>}
          <button onClick={()=>setShowSettings(true)} style={{background:'#ffffff08',border:'1px solid #ffffff11',color:'#aaa',padding:'6px 12px',borderRadius:8,cursor:'pointer',fontSize:11}}>⚙️</button>
        </div>
      </div>

      {/* URL Bar */}
      <div style={{padding:'10px 14px',background:'#08081a',borderBottom:'1px solid #ffffff06'}}>
        <div style={{display:'flex',gap:8}}>
          <input value={url} onChange={e=>setUrl(e.target.value)} onKeyDown={e=>e.key==='Enter'&&scan()}
            placeholder="example.com বা https://yoursite.com"
            style={{flex:1,background:'#0d0d1a',border:'1px solid #ffffff15',borderRadius:10,padding:'10px 12px',color:'#fff',fontSize:12,fontFamily:'JetBrains Mono,monospace'}}
          />
          <button onClick={scan} disabled={loading} style={{background:loading?'#1a1a2e':'linear-gradient(135deg,#00d4ff,#0070f3)',border:'none',borderRadius:10,padding:'10px 16px',color:loading?'#555':'#fff',fontWeight:700,cursor:loading?'not-allowed':'pointer',fontFamily:'Rajdhani',letterSpacing:1,fontSize:12,whiteSpace:'nowrap',display:'flex',alignItems:'center',gap:6}}>
            {loading?<><span style={{animation:'spin 1s linear infinite',display:'inline-block'}}>⟳</span>স্ক্যানিং...</>:<>🔍 Full Scan</>}
          </button>
        </div>
        {/* Settings indicators */}
        <div style={{display:'flex',gap:6,marginTop:6,flexWrap:'wrap'}}>
          {settings.useProxy&&<Badge color="green" small>🌐 Proxy ON</Badge>}
          {settings.useDelay!==false&&<Badge color="blue" small>⏱️ Smart Delay</Badge>}
          {settings.cookies&&<Badge color="yellow" small>🍪 Cookie SET</Badge>}
          {settings.headersRaw&&<Badge color="purple" small>🔑 Custom Headers</Badge>}
        </div>
        {errors.global&&<div style={{background:'#ff475718',border:'1px solid #ff475744',borderRadius:8,padding:'7px 12px',marginTop:8,color:'#ff6b7a',fontSize:11}}>❌ {errors.global}</div>}
      </div>

      {/* Tabs */}
      <div style={{overflowX:'auto',borderBottom:'1px solid #ffffff08',background:'#08081a',position:'sticky',top:57,zIndex:40}}>
        <div style={{display:'flex',minWidth:'max-content'}}>
          {TABS.map(tab=>{
            const hasData=!!results?.[tab.id];
            const hasErr=!!errors?.[tab.id];
            const isLoad=tabLoading===tab.id;
            return <button key={tab.id} onClick={()=>{setActiveTab(tab.id);if(!hasData&&!isLoad)scanTab(tab.id);}} style={{padding:'8px 12px',background:'none',border:'none',borderBottom:`2px solid ${activeTab===tab.id?'#00d4ff':'transparent'}`,color:activeTab===tab.id?'#00d4ff':hasErr?'#ff6b7a':'#ffffff44',cursor:'pointer',fontSize:11,fontWeight:activeTab===tab.id?700:400,whiteSpace:'nowrap',fontFamily:'Rajdhani',letterSpacing:0.5,display:'flex',alignItems:'center',gap:4,transition:'color 0.2s'}}>
              {tab.icon} {tab.label}
              {isLoad&&<span style={{animation:'spin 1s linear infinite',display:'inline-block',fontSize:11}}>⟳</span>}
              {hasData&&!isLoad&&<span style={{color:'#00d08488',fontSize:8}}>●</span>}
              {hasErr&&<span style={{color:'#ff475788',fontSize:8}}>✕</span>}
            </button>;
          })}
        </div>
      </div>

      {/* Content */}
      <div style={{padding:'10px 14px',minHeight:'calc(100vh - 200px)'}}>
        {loading?(
          <div style={{textAlign:'center',padding:'60px 0'}}>
            <div style={{fontSize:48,animation:'spin 2s linear infinite',display:'inline-block'}}>🕷️</div>
            <p style={{color:'#555',marginTop:12,fontSize:12}}>সব ট্যাব একসাথে স্ক্যান হচ্ছে...</p>
            <div style={{display:'flex',gap:8,justifyContent:'center',flexWrap:'wrap',marginTop:10}}>
              {TABS.map((t,i)=><span key={t.id} style={{color:'#333',fontSize:14,animation:'pulse 1.5s ease infinite',animationDelay:`${i*0.1}s`}}>{t.icon}</span>)}
            </div>
          </div>
        ):!results&&!Object.keys(errors).filter(k=>k!=='global').length?(
          <div style={{textAlign:'center',padding:'50px 0'}}>
            <div style={{fontSize:48,opacity:0.15}}>🕷️</div>
            <p style={{color:'#333',marginTop:10,fontSize:12}}>URL দিয়ে স্ক্যান শুরু করুন</p>
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(140px,1fr))',gap:8,marginTop:16,maxWidth:600,margin:'16px auto 0'}}>
              {TABS.map(t=>(
                <div key={t.id} style={{background:'#ffffff05',border:'1px solid #ffffff08',borderRadius:8,padding:'8px 10px',textAlign:'left'}}>
                  <div style={{fontSize:16,marginBottom:4}}>{t.icon} <span style={{color:'#aaa',fontSize:11,fontFamily:'Rajdhani',fontWeight:700}}>{t.label}</span></div>
                  <div style={{color:'#444',fontSize:9}}>{t.desc}</div>
                </div>
              ))}
            </div>
          </div>
        ):(
          <div className="fade">
            {errors[activeTab]&&<div style={{background:'#ff475718',border:'1px solid #ff475744',borderRadius:8,padding:'7px 12px',marginBottom:10,color:'#ff6b7a',fontSize:11,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <span>❌ {errors[activeTab]}</span>
              <button onClick={()=>scanTab(activeTab)} style={{background:'#ff475733',border:'none',color:'#ff6b7a',borderRadius:6,padding:'3px 10px',cursor:'pointer',fontSize:10}}>Retry ⟳</button>
            </div>}
            {tabLoading===activeTab?(
              <div style={{textAlign:'center',padding:'40px'}}>
                <div style={{animation:'spin 1s linear infinite',display:'inline-block',fontSize:30,color:'#00d4ff'}}>⟳</div>
                <p style={{color:'#555',fontSize:11,marginTop:8}}>লোড হচ্ছে...</p>
              </div>
            ):tabComponents[activeTab]}
          </div>
        )}
      </div>

      {showExport&&<ExportPanel scanData={scanData} onClose={()=>setShowExport(false)}/>}
      {showSettings&&<SettingsPanel settings={settings} onChange={setSettings} onClose={()=>setShowSettings(false)}/>}
    </div>
  );
}
