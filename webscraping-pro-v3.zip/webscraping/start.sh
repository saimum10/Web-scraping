#!/bin/bash
echo ""
echo "╔══════════════════════════════════════╗"
echo "║   🕷️  Web Scraping Pro v3            ║"
echo "║   http://localhost:3001              ║"
echo "║   Ctrl+C to stop                    ║"
echo "╚══════════════════════════════════════╝"
echo ""
cd backend && node server.js
