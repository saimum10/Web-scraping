# 🕷️ Web Scraping Pro v3

## 📋 সব ফিচার

| ট্যাব | বিবরণ |
|-------|-------|
| 🌐 HTML | লিংক, ইমেজ, ফর্ম, ইমেইল, ফোন |
| 📋 Meta | SEO, Open Graph, Twitter Card, Schema.org |
| ⚙️ JS Audit | API Keys, Firebase, AWS, Stripe, Streaming URLs |
| 🔌 API Finder | Endpoints, GraphQL, WebSocket, XHR, Path Probe |
| 🍪 Cookies | Session, Auth, JWT decode, localStorage |
| 🔧 Technology | Framework, CMS, Library detection (80+ tech) |
| 🛡️ Security | Headers Score, Server info, HTTPS check |
| 🔍 DNS/WHOIS | IP, NS, MX, TXT, CDN, WHOIS |
| 📊 Trackers | GA, GTM, Facebook Pixel, Hotjar, Stripe |
| 🌐 Subdomains | CT Log + DNS Bruteforce (300+ wordlist) |
| 📂 Directories | 500+ path bruteforce, critical file detection |
| 🤖 Robots | robots.txt, Sitemap URLs |

## 🚀 Termux Setup

```bash
unzip webscraping-pro-v3.zip
cd webscraping
chmod +x setup.sh start.sh build-apk.sh
bash setup.sh
bash start.sh
```

Browser: `http://localhost:3001`

## 📱 APK বানানো

```bash
bash build-apk.sh
# APK: android/app/build/outputs/apk/debug/app-debug.apk
```

## 📥 Export ফরম্যাট

- **PDF** — পেশাদার client রিপোর্ট
- **JSON** — Raw data, API integration
- **CSV** — Excel-এ analysis
- **HTML** — Interactive browser report  
- **Markdown** — GitHub/Notion documentation
- **TXT** — Plain text summary

## ⚙️ Advanced Features

- **Custom Headers** — Authorization, X-API-Key যোগ করুন
- **Session Cookie** — Login-এর পেছনের পেজ scan করুন
- **Free Proxy Rotation** — IP block এড়ান
- **Smart Delay** — Rate limit bypass (auto)
