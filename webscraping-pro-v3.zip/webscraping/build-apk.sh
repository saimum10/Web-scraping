#!/bin/bash
# ══════════════════════════════════════════════
#   APK Build Script — Web Scraping Pro
# ══════════════════════════════════════════════

echo "📱 APK Build শুরু হচ্ছে..."
echo ""

# Build frontend
echo "[1/5] Frontend build..."
cd frontend && npm run build && cd ..
echo "✅ Build done"

# Install Capacitor deps
echo ""
echo "[2/5] Capacitor ইনস্টল..."
npm install --silent
echo "✅ Capacitor ready"

# Add/sync Android
echo ""
if [ ! -d "android" ]; then
    echo "[3/5] Android platform যোগ হচ্ছে..."
    npx cap add android
else
    echo "[3/5] Capacitor sync..."
    npx cap sync android
fi

# Set app icon
echo ""
echo "[4/5] App icon সেট করা হচ্ছে..."
ICON_SRC="assets/icon.png"
if [ -f "$ICON_SRC" ]; then
    for size in "mdpi:48" "hdpi:72" "xhdpi:96" "xxhdpi:144" "xxxhdpi:192"; do
        dir=$(echo $size | cut -d: -f1)
        RES_DIR="android/app/src/main/res/mipmap-${dir}"
        if [ -d "$RES_DIR" ]; then
            cp "$ICON_SRC" "$RES_DIR/ic_launcher.png" 2>/dev/null || true
            cp "$ICON_SRC" "$RES_DIR/ic_launcher_round.png" 2>/dev/null || true
        fi
    done
    echo "✅ Icon সেট হয়েছে"
else
    echo "⚠️  assets/icon.png পাওয়া যায়নি"
fi

# Set app name
echo ""
echo "[5/5] App নাম সেট করা হচ্ছে..."
STRINGS_FILE="android/app/src/main/res/values/strings.xml"
if [ -f "$STRINGS_FILE" ]; then
    sed -i 's|<string name="app_name">.*</string>|<string name="app_name">Web Scraping</string>|g' "$STRINGS_FILE"
    echo "✅ App নাম: Web Scraping"
fi

# Build APK
echo ""
echo "🔨 APK তৈরি হচ্ছে (এটা কিছুক্ষণ সময় নেবে)..."
cd android && ./gradlew assembleDebug 2>&1 | tail -5
cd ..

echo ""
echo "══════════════════════════════════════"
APK_PATH="android/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
    SIZE=$(du -h "$APK_PATH" | cut -f1)
    echo "✅ APK তৈরি হয়েছে! ($SIZE)"
    echo ""
    echo "📦 Location:"
    echo "   $APK_PATH"
    echo ""
    echo "📱 ফোনে ইনস্টল করতে:"
    echo "   cp $APK_PATH /sdcard/WebScraping.apk"
else
    echo "❌ APK build ব্যর্থ হয়েছে"
    echo "Android Studio দিয়ে চেষ্টা করুন:"
    echo "   npx cap open android"
fi
echo "══════════════════════════════════════"
