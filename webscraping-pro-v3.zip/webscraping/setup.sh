#!/bin/bash
# ══════════════════════════════════════════════
#   Web Scraping Pro v3 — Termux Setup
# ══════════════════════════════════════════════
set -e

echo ""
echo "╔══════════════════════════════════════╗"
echo "║   🕷️  Web Scraping Pro v3 Setup      ║"
echo "╚══════════════════════════════════════╝"
echo ""

# Step 1: Node.js
echo "📦 [1/5] Node.js চেক করা হচ্ছে..."
if ! command -v node &> /dev/null; then
    echo "Node.js ইনস্টল হচ্ছে..."
    pkg update -y -q
    pkg install -y nodejs
else
    echo "✅ Node.js $(node -v)"
fi

# Step 2: Backend
echo ""
echo "🔧 [2/5] Backend প্যাকেজ ইনস্টল..."
cd backend
npm install --silent
echo "✅ Backend ready"
cd ..

# Step 3: Frontend
echo ""
echo "🎨 [3/5] Frontend প্যাকেজ ইনস্টল..."
cd frontend
npm install --silent
echo "✅ Frontend packages ready"

# Step 4: Build
echo ""
echo "🏗️ [4/5] Frontend build হচ্ছে..."
npm run build
echo "✅ Build সম্পন্ন"
cd ..

# Step 5: Make scripts executable
echo ""
echo "🔑 [5/5] Scripts permission..."
chmod +x start.sh build-apk.sh 2>/dev/null || true
echo "✅ Done"

echo ""
echo "══════════════════════════════════════"
echo "✅ সেটআপ সম্পন্ন!"
echo ""
echo "🚀 চালাতে:   bash start.sh"
echo "📱 APK:      bash build-apk.sh"
echo "🌐 Browser:  http://localhost:3001"
echo "══════════════════════════════════════"
